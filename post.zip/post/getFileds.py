"""
print("UNITED STATES OF AMERICA\nPASSPORT CARD\nPassport Card "
      "\nC00001549\nNationality\nUSA\nSurname\nTRAVELER\n"
      "Qiven Names\nHAPPY\nDate of Birth\n01 JAN 1981\nPlace of Birth\n"
      "NEW YORK. USA\nisued On\n6 MAY 08\nExpires On\n15 MAY 18\nA123456\n"
      "UNITED STATEB DEPARTMENT OF STATE\n2uAUS4\n")

print("UNITED STATES OF AMERICA\nPASSPORT CARD\n"
      "FLUT\nNationality\nUSA\nPassport Card no.\n"
      "CO3004786\n**\nEXEMPLAR\nSurname\nTRAVELER\n"
      "Given Names\nHAPPY\nSex\nDate of Birth\n"
      "W1JAN 1981\nPlace of Birth\n2\nNEW YORK. U.S.A.\n"
      "7\nExpires On\n29 NOV 2019\nIssued On\n30 NOV 2009\n"
      "M-6131821-07\ne RDATE T TATES DEPARTMENT OF SATE\n"
      "1-02781-0\n, כ\nC עב\u003c\n")
"""
"""
{
  "responses": [
    {
      "textAnnotations": [
        {
          "locale": "en",
          "description": "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
          "boundingPoly": {
            "vertices": [
              {
                "x": 26,
                "y": 15
              },
              {
                "x": 464,
                "y": 15
              },
              {
                "x": 464,
                "y": 296
              },
              {
                "x": 26,
                "y": 296
              }
            ]
          }
        },
        {
          "description": "UNITED",
          "boundingPoly": {
            "vertices": [
              {
                "x": 27,
                "y": 16
              },
              {
                "x": 153,
                "y": 16
              },
              {
                "x": 153,
                "y": 37
              },
              {
                "x": 27,
                "y": 37
              }
            ]
          }
        },
        {
          "description": "STATES",
          "boundingPoly": {
            "vertices": [
              {
                "x": 160,
                "y": 18
              },
              {
                "x": 272,
                "y": 18
              },
              {
                "x": 272,
                "y": 36
              },
              {
                "x": 160,
                "y": 36
              }
            ]
          }
        },
        {
          "description": "OF",
          "boundingPoly": {
            "vertices": [
              {
                "x": 280,
                "y": 18
              },
              {
                "x": 320,
                "y": 18
              },
              {
                "x": 320,
                "y": 35
              },
              {
                "x": 280,
                "y": 35
              }
            ]
          }
        },
        {
          "description": "AMERICA",
          "boundingPoly": {
            "vertices": [
              {
                "x": 327,
                "y": 15
              },
              {
                "x": 464,
                "y": 15
              },
              {
                "x": 464,
                "y": 37
              },
              {
                "x": 327,
                "y": 37
              }
            ]
          }
        },
        {
          "description": "PASSPORT",
          "boundingPoly": {
            "vertices": [
              {
                "x": 131,
                "y": 43
              },
              {
                "x": 274,
                "y": 43
              },
              {
                "x": 274,
                "y": 53
              },
              {
                "x": 131,
                "y": 53
              }
            ]
          }
        },
        {
          "description": "CARD",
          "boundingPoly": {
            "vertices": [
              {
                "x": 290,
                "y": 39
              },
              {
                "x": 359,
                "y": 39
              },
              {
                "x": 359,
                "y": 55
              },
              {
                "x": 290,
                "y": 55
              }
            ]
          }
        },
        {
          "description": "Passport",
          "boundingPoly": {
            "vertices": [
              {
                "x": 348,
                "y": 60
              },
              {
                "x": 401,
                "y": 60
              },
              {
                "x": 401,
                "y": 73
              },
              {
                "x": 348,
                "y": 73
              }
            ]
          }
        },
        {
          "description": "Card",
          "boundingPoly": {
            "vertices": [
              {
                "x": 406,
                "y": 60
              },
              {
                "x": 433,
                "y": 60
              },
              {
                "x": 433,
                "y": 72
              },
              {
                "x": 406,
                "y": 72
              }
            ]
          }
        },
        {
          "description": "No.",
          "boundingPoly": {
            "vertices": [
              {
                "x": 437,
                "y": 58
              },
              {
                "x": 455,
                "y": 58
              },
              {
                "x": 455,
                "y": 72
              },
              {
                "x": 437,
                "y": 72
              }
            ]
          }
        },
        {
          "description": "C00003594",
          "boundingPoly": {
            "vertices": [
              {
                "x": 347,
                "y": 71
              },
              {
                "x": 442,
                "y": 71
              },
              {
                "x": 442,
                "y": 87
              },
              {
                "x": 347,
                "y": 87
              }
            ]
          }
        },
        {
          "description": "Nationality",
          "boundingPoly": {
            "vertices": [
              {
                "x": 223,
                "y": 78
              },
              {
                "x": 278,
                "y": 79
              },
              {
                "x": 278,
                "y": 92
              },
              {
                "x": 223,
                "y": 91
              }
            ]
          }
        },
        {
          "description": "USA",
          "boundingPoly": {
            "vertices": [
              {
                "x": 223,
                "y": 91
              },
              {
                "x": 252,
                "y": 91
              },
              {
                "x": 252,
                "y": 103
              },
              {
                "x": 223,
                "y": 103
              }
            ]
          }
        },
        {
          "description": "Surname",
          "boundingPoly": {
            "vertices": [
              {
                "x": 223,
                "y": 113
              },
              {
                "x": 269,
                "y": 114
              },
              {
                "x": 269,
                "y": 123
              },
              {
                "x": 223,
                "y": 122
              }
            ]
          }
        },
        {
          "description": "TRAVELER",
          "boundingPoly": {
            "vertices": [
              {
                "x": 222,
                "y": 125
              },
              {
                "x": 299,
                "y": 126
              },
              {
                "x": 299,
                "y": 138
              },
              {
                "x": 222,
                "y": 137
              }
            ]
          }
        },
        {
          "description": "Given",
          "boundingPoly": {
            "vertices": [
              {
                "x": 220,
                "y": 147
              },
              {
                "x": 252,
                "y": 147
              },
              {
                "x": 252,
                "y": 156
              },
              {
                "x": 220,
                "y": 156
              }
            ]
          }
        },
        {
          "description": "Names",
          "boundingPoly": {
            "vertices": [
              {
                "x": 258,
                "y": 147
              },
              {
                "x": 292,
                "y": 147
              },
              {
                "x": 292,
                "y": 155
              },
              {
                "x": 258,
                "y": 155
              }
            ]
          }
        },
        {
          "description": "HAPPY",
          "boundingPoly": {
            "vertices": [
              {
                "x": 217,
                "y": 155
              },
              {
                "x": 272,
                "y": 155
              },
              {
                "x": 272,
                "y": 172
              },
              {
                "x": 217,
                "y": 172
              }
            ]
          }
        },
        {
          "description": "xxx",
          "boundingPoly": {
            "vertices": [
              {
                "x": 223,
                "y": 179
              },
              {
                "x": 240,
                "y": 179
              },
              {
                "x": 240,
                "y": 190
              },
              {
                "x": 223,
                "y": 190
              }
            ]
          }
        },
        {
          "description": "Date",
          "boundingPoly": {
            "vertices": [
              {
                "x": 283,
                "y": 181
              },
              {
                "x": 305,
                "y": 181
              },
              {
                "x": 305,
                "y": 188
              },
              {
                "x": 283,
                "y": 188
              }
            ]
          }
        },
        {
          "description": "of",
          "boundingPoly": {
            "vertices": [
              {
                "x": 311,
                "y": 181
              },
              {
                "x": 319,
                "y": 181
              },
              {
                "x": 319,
                "y": 188
              },
              {
                "x": 311,
                "y": 188
              }
            ]
          }
        },
        {
          "description": "Birth",
          "boundingPoly": {
            "vertices": [
              {
                "x": 324,
                "y": 181
              },
              {
                "x": 348,
                "y": 181
              },
              {
                "x": 348,
                "y": 188
              },
              {
                "x": 324,
                "y": 188
              }
            ]
          }
        },
        {
          "description": "01",
          "boundingPoly": {
            "vertices": [
              {
                "x": 283,
                "y": 192
              },
              {
                "x": 296,
                "y": 192
              },
              {
                "x": 296,
                "y": 203
              },
              {
                "x": 283,
                "y": 203
              }
            ]
          }
        },
        {
          "description": "JAN",
          "boundingPoly": {
            "vertices": [
              {
                "x": 305,
                "y": 192
              },
              {
                "x": 333,
                "y": 192
              },
              {
                "x": 333,
                "y": 203
              },
              {
                "x": 305,
                "y": 203
              }
            ]
          }
        },
        {
          "description": "1981",
          "boundingPoly": {
            "vertices": [
              {
                "x": 341,
                "y": 192
              },
              {
                "x": 369,
                "y": 192
              },
              {
                "x": 369,
                "y": 203
              },
              {
                "x": 341,
                "y": 203
              }
            ]
          }
        },
        {
          "description": "Place",
          "boundingPoly": {
            "vertices": [
              {
                "x": 220,
                "y": 212
              },
              {
                "x": 250,
                "y": 212
              },
              {
                "x": 250,
                "y": 224
              },
              {
                "x": 220,
                "y": 224
              }
            ]
          }
        },
        {
          "description": "of",
          "boundingPoly": {
            "vertices": [
              {
                "x": 255,
                "y": 215
              },
              {
                "x": 264,
                "y": 215
              },
              {
                "x": 264,
                "y": 222
              },
              {
                "x": 255,
                "y": 222
              }
            ]
          }
        },
        {
          "description": "Birth",
          "boundingPoly": {
            "vertices": [
              {
                "x": 269,
                "y": 215
              },
              {
                "x": 292,
                "y": 215
              },
              {
                "x": 292,
                "y": 223
              },
              {
                "x": 269,
                "y": 223
              }
            ]
          }
        },
        {
          "description": "NEW",
          "boundingPoly": {
            "vertices": [
              {
                "x": 217,
                "y": 224
              },
              {
                "x": 257,
                "y": 224
              },
              {
                "x": 257,
                "y": 240
              },
              {
                "x": 217,
                "y": 240
              }
            ]
          }
        },
        {
          "description": "YORK.",
          "boundingPoly": {
            "vertices": [
              {
                "x": 264,
                "y": 226
              },
              {
                "x": 306,
                "y": 226
              },
              {
                "x": 306,
                "y": 238
              },
              {
                "x": 264,
                "y": 238
              }
            ]
          }
        },
        {
          "description": "USA",
          "boundingPoly": {
            "vertices": [
              {
                "x": 314,
                "y": 226
              },
              {
                "x": 342,
                "y": 226
              },
              {
                "x": 342,
                "y": 237
              },
              {
                "x": 314,
                "y": 237
              }
            ]
          }
        },
        {
          "description": "Expires",
          "boundingPoly": {
            "vertices": [
              {
                "x": 354,
                "y": 247
              },
              {
                "x": 392,
                "y": 246
              },
              {
                "x": 392,
                "y": 257
              },
              {
                "x": 354,
                "y": 258
              }
            ]
          }
        },
        {
          "description": "On",
          "boundingPoly": {
            "vertices": [
              {
                "x": 397,
                "y": 248
              },
              {
                "x": 411,
                "y": 248
              },
              {
                "x": 411,
                "y": 256
              },
              {
                "x": 397,
                "y": 256
              }
            ]
          }
        },
        {
          "description": "15",
          "boundingPoly": {
            "vertices": [
              {
                "x": 355,
                "y": 258
              },
              {
                "x": 368,
                "y": 258
              },
              {
                "x": 368,
                "y": 271
              },
              {
                "x": 355,
                "y": 271
              }
            ]
          }
        },
        {
          "description": "MAY",
          "boundingPoly": {
            "vertices": [
              {
                "x": 376,
                "y": 260
              },
              {
                "x": 406,
                "y": 260
              },
              {
                "x": 406,
                "y": 271
              },
              {
                "x": 376,
                "y": 271
              }
            ]
          }
        },
        {
          "description": "18",
          "boundingPoly": {
            "vertices": [
              {
                "x": 413,
                "y": 260
              },
              {
                "x": 427,
                "y": 260
              },
              {
                "x": 427,
                "y": 271
              },
              {
                "x": 413,
                "y": 271
              }
            ]
          }
        },
        {
          "description": "ssued",
          "boundingPoly": {
            "vertices": [
              {
                "x": 222,
                "y": 248
              },
              {
                "x": 256,
                "y": 247
              },
              {
                "x": 256,
                "y": 257
              },
              {
                "x": 222,
                "y": 258
              }
            ]
          }
        },
        {
          "description": "On",
          "boundingPoly": {
            "vertices": [
              {
                "x": 261,
                "y": 248
              },
              {
                "x": 275,
                "y": 248
              },
              {
                "x": 275,
                "y": 256
              },
              {
                "x": 261,
                "y": 256
              }
            ]
          }
        },
        {
          "description": "6",
          "boundingPoly": {
            "vertices": [
              {
                "x": 226,
                "y": 259
              },
              {
                "x": 238,
                "y": 259
              },
              {
                "x": 238,
                "y": 274
              },
              {
                "x": 226,
                "y": 274
              }
            ]
          }
        },
        {
          "description": "MAY",
          "boundingPoly": {
            "vertices": [
              {
                "x": 245,
                "y": 260
              },
              {
                "x": 275,
                "y": 260
              },
              {
                "x": 275,
                "y": 272
              },
              {
                "x": 245,
                "y": 272
              }
            ]
          }
        },
        {
          "description": "08",
          "boundingPoly": {
            "vertices": [
              {
                "x": 281,
                "y": 260
              },
              {
                "x": 296,
                "y": 260
              },
              {
                "x": 296,
                "y": 271
              },
              {
                "x": 281,
                "y": 271
              }
            ]
          }
        },
        {
          "description": "A123456",
          "boundingPoly": {
            "vertices": [
              {
                "x": 26,
                "y": 271
              },
              {
                "x": 89,
                "y": 271
              },
              {
                "x": 89,
                "y": 285
              },
              {
                "x": 26,
                "y": 285
              }
            ]
          }
        },
        {
          "description": "m",
          "boundingPoly": {
            "vertices": [
              {
                "x": 45,
                "y": 283
              },
              {
                "x": 57,
                "y": 283
              },
              {
                "x": 57,
                "y": 296
              },
              {
                "x": 45,
                "y": 296
              }
            ]
          }
        },
        {
          "description": "UNITED",
          "boundingPoly": {
            "vertices": [
              {
                "x": 75,
                "y": 283
              },
              {
                "x": 139,
                "y": 283
              },
              {
                "x": 139,
                "y": 295
              },
              {
                "x": 75,
                "y": 295
              }
            ]
          }
        },
        {
          "description": "STATES",
          "boundingPoly": {
            "vertices": [
              {
                "x": 148,
                "y": 287
              },
              {
                "x": 210,
                "y": 287
              },
              {
                "x": 210,
                "y": 294
              },
              {
                "x": 148,
                "y": 294
              }
            ]
          }
        },
        {
          "description": "DEPARTMENT",
          "boundingPoly": {
            "vertices": [
              {
                "x": 219,
                "y": 287
              },
              {
                "x": 333,
                "y": 287
              },
              {
                "x": 333,
                "y": 294
              },
              {
                "x": 219,
                "y": 294
              }
            ]
          }
        },
        {
          "description": "OF",
          "boundingPoly": {
            "vertices": [
              {
                "x": 342,
                "y": 287
              },
              {
                "x": 362,
                "y": 287
              },
              {
                "x": 362,
                "y": 294
              },
              {
                "x": 342,
                "y": 294
              }
            ]
          }
        },
        {
          "description": "STATE",
          "boundingPoly": {
            "vertices": [
              {
                "x": 374,
                "y": 283
              },
              {
                "x": 421,
                "y": 283
              },
              {
                "x": 421,
                "y": 296
              },
              {
                "x": 374,
                "y": 296
              }
            ]
          }
        },
        {
          "description": "USAUSA",
          "boundingPoly": {
            "vertices": [
              {
                "x": 171,
                "y": 77
              },
              {
                "x": 170,
                "y": 156
              },
              {
                "x": 159,
                "y": 156
              },
              {
                "x": 160,
                "y": 77
              }
            ]
          }
        }
      ],
      "fullTextAnnotation": {
        "pages": [
          {
            "property": {
              "detectedLanguages": [
                {
                  "languageCode": "en",
                  "confidence": 0.91
                },
                {
                  "languageCode": "ceb",
                  "confidence": 0.03
                }
              ]
            },
            "width": 500,
            "height": 315,
            "blocks": [
              {
                "property": {
                  "detectedLanguages": [
                    {
                      "languageCode": "en",
                      "confidence": 1
                    }
                  ]
                },
                "boundingBox": {
                  "vertices": [
                    {
                      "x": 27,
                      "y": 15
                    },
                    {
                      "x": 464,
                      "y": 15
                    },
                    {
                      "x": 464,
                      "y": 55
                    },
                    {
                      "x": 27,
                      "y": 55
                    }
                  ]
                },
                "paragraphs": [
                  {
                    "property": {
                      "detectedLanguages": [
                        {
                          "languageCode": "en",
                          "confidence": 1
                        }
                      ]
                    },
                    "boundingBox": {
                      "vertices": [
                        {
                          "x": 27,
                          "y": 15
                        },
                        {
                          "x": 464,
                          "y": 15
                        },
                        {
                          "x": 464,
                          "y": 55
                        },
                        {
                          "x": 27,
                          "y": 55
                        }
                      ]
                    },
                    "words": [
                      {
                        "property": {
                          "detectedLanguages": [
                            {
                              "languageCode": "en"
                            }
                          ]
                        },
                        "boundingBox": {
                          "vertices": [
                            {
                              "x": 27,
                              "y": 16
                            },
                            {
                              "x": 153,
                              "y": 16
                            },
                            {
                              "x": 153,
                              "y": 37
                            },
                            {
                              "x": 27,
                              "y": 37
                            }
                          ]
                        },
                        "symbols": [
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 27,
                                  "y": 16
                                },
                                {
                                  "x": 58,
                                  "y": 16
                                },
                                {
                                  "x": 58,
                                  "y": 37
                                },
                                {
                                  "x": 27,
                                  "y": 37
                                }
                              ]
                            },
                            "text": "U"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 59,
                                  "y": 16
                                },
                                {
                                  "x": 77,
                                  "y": 16
                                },
                                {
                                  "x": 77,
                                  "y": 37
                                },
                                {
                                  "x": 59,
                                  "y": 37
                                }
                              ]
                            },
                            "text": "N"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 78,
                                  "y": 16
                                },
                                {
                                  "x": 93,
                                  "y": 16
                                },
                                {
                                  "x": 93,
                                  "y": 37
                                },
                                {
                                  "x": 78,
                                  "y": 37
                                }
                              ]
                            },
                            "text": "I"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 94,
                                  "y": 16
                                },
                                {
                                  "x": 108,
                                  "y": 16
                                },
                                {
                                  "x": 108,
                                  "y": 37
                                },
                                {
                                  "x": 94,
                                  "y": 37
                                }
                              ]
                            },
                            "text": "T"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 109,
                                  "y": 16
                                },
                                {
                                  "x": 131,
                                  "y": 16
                                },
                                {
                                  "x": 131,
                                  "y": 37
                                },
                                {
                                  "x": 109,
                                  "y": 37
                                }
                              ]
                            },
                            "text": "E"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ],
                              "detectedBreak": {
                                "type": "SPACE"
                              }
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 132,
                                  "y": 16
                                },
                                {
                                  "x": 153,
                                  "y": 16
                                },
                                {
                                  "x": 153,
                                  "y": 37
                                },
                                {
                                  "x": 132,
                                  "y": 37
                                }
                              ]
                            },
                            "text": "D"
                          }
                        ]
                      },
                      {
                        "property": {
                          "detectedLanguages": [
                            {
                              "languageCode": "en"
                            }
                          ]
                        },
                        "boundingBox": {
                          "vertices": [
                            {
                              "x": 160,
                              "y": 18
                            },
                            {
                              "x": 272,
                              "y": 18
                            },
                            {
                              "x": 272,
                              "y": 36
                            },
                            {
                              "x": 160,
                              "y": 36
                            }
                          ]
                        },
                        "symbols": [
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 160,
                                  "y": 18
                                },
                                {
                                  "x": 185,
                                  "y": 18
                                },
                                {
                                  "x": 185,
                                  "y": 36
                                },
                                {
                                  "x": 160,
                                  "y": 36
                                }
                              ]
                            },
                            "text": "S"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 186,
                                  "y": 18
                                },
                                {
                                  "x": 200,
                                  "y": 18
                                },
                                {
                                  "x": 200,
                                  "y": 36
                                },
                                {
                                  "x": 186,
                                  "y": 36
                                }
                              ]
                            },
                            "text": "T"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 201,
                                  "y": 18
                                },
                                {
                                  "x": 211,
                                  "y": 18
                                },
                                {
                                  "x": 211,
                                  "y": 36
                                },
                                {
                                  "x": 201,
                                  "y": 36
                                }
                              ]
                            },
                            "text": "A"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 212,
                                  "y": 18
                                },
                                {
                                  "x": 234,
                                  "y": 18
                                },
                                {
                                  "x": 234,
                                  "y": 36
                                },
                                {
                                  "x": 212,
                                  "y": 36
                                }
                              ]
                            },
                            "text": "T"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 235,
                                  "y": 18
                                },
                                {
                                  "x": 254,
                                  "y": 18
                                },
                                {
                                  "x": 254,
                                  "y": 36
                                },
                                {
                                  "x": 235,
                                  "y": 36
                                }
                              ]
                            },
                            "text": "E"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ],
                              "detectedBreak": {
                                "type": "SPACE"
                              }
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 255,
                                  "y": 18
                                },
                                {
                                  "x": 272,
                                  "y": 18
                                },
                                {
                                  "x": 272,
                                  "y": 36
                                },
                                {
                                  "x": 255,
                                  "y": 36
                                }
                              ]
                            },
                            "text": "S"
                          }
                        ]
                      },
                      {
                        "property": {
                          "detectedLanguages": [
                            {
                              "languageCode": "en"
                            }
                          ]
                        },
                        "boundingBox": {
                          "vertices": [
                            {
                              "x": 280,
                              "y": 18
                            },
                            {
                              "x": 320,
                              "y": 18
                            },
                            {
                              "x": 320,
                              "y": 35
                            },
                            {
                              "x": 280,
                              "y": 35
                            }
                          ]
                        },
                        "symbols": [
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 280,
                                  "y": 18
                                },
                                {
                                  "x": 303,
                                  "y": 18
                                },
                                {
                                  "x": 303,
                                  "y": 35
                                },
                                {
                                  "x": 280,
                                  "y": 35
                                }
                              ]
                            },
                            "text": "O"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ],
                              "detectedBreak": {
                                "type": "SPACE"
                              }
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 304,
                                  "y": 18
                                },
                                {
                                  "x": 320,
                                  "y": 18
                                },
                                {
                                  "x": 320,
                                  "y": 35
                                },
                                {
                                  "x": 304,
                                  "y": 35
                                }
                              ]
                            },
                            "text": "F"
                          }
                        ]
                      },
                      {
                        "property": {
                          "detectedLanguages": [
                            {
                              "languageCode": "en"
                            }
                          ]
                        },
                        "boundingBox": {
                          "vertices": [
                            {
                              "x": 327,
                              "y": 15
                            },
                            {
                              "x": 464,
                              "y": 15
                            },
                            {
                              "x": 464,
                              "y": 37
                            },
                            {
                              "x": 327,
                              "y": 37
                            }
                          ]
                        },
                        "symbols": [
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 327,
                                  "y": 15
                                },
                                {
                                  "x": 346,
                                  "y": 15
                                },
                                {
                                  "x": 346,
                                  "y": 37
                                },
                                {
                                  "x": 327,
                                  "y": 37
                                }
                              ]
                            },
                            "text": "A"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 347,
                                  "y": 15
                                },
                                {
                                  "x": 369,
                                  "y": 15
                                },
                                {
                                  "x": 369,
                                  "y": 37
                                },
                                {
                                  "x": 347,
                                  "y": 37
                                }
                              ]
                            },
                            "text": "M"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 370,
                                  "y": 15
                                },
                                {
                                  "x": 392,
                                  "y": 15
                                },
                                {
                                  "x": 392,
                                  "y": 37
                                },
                                {
                                  "x": 370,
                                  "y": 37
                                }
                              ]
                            },
                            "text": "E"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 393,
                                  "y": 15
                                },
                                {
                                  "x": 411,
                                  "y": 15
                                },
                                {
                                  "x": 411,
                                  "y": 37
                                },
                                {
                                  "x": 393,
                                  "y": 37
                                }
                              ]
                            },
                            "text": "R"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 412,
                                  "y": 15
                                },
                                {
                                  "x": 434,
                                  "y": 15
                                },
                                {
                                  "x": 434,
                                  "y": 37
                                },
                                {
                                  "x": 412,
                                  "y": 37
                                }
                              ]
                            },
                            "text": "I"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 435,
                                  "y": 15
                                },
                                {
                                  "x": 449,
                                  "y": 15
                                },
                                {
                                  "x": 449,
                                  "y": 37
                                },
                                {
                                  "x": 435,
                                  "y": 37
                                }
                              ]
                            },
                            "text": "C"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ],
                              "detectedBreak": {
                                "type": "EOL_SURE_SPACE"
                              }
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 450,
                                  "y": 15
                                },
                                {
                                  "x": 464,
                                  "y": 15
                                },
                                {
                                  "x": 464,
                                  "y": 37
                                },
                                {
                                  "x": 450,
                                  "y": 37
                                }
                              ]
                            },
                            "text": "A"
                          }
                        ]
                      },
                      {
                        "property": {
                          "detectedLanguages": [
                            {
                              "languageCode": "en"
                            }
                          ]
                        },
                        "boundingBox": {
                          "vertices": [
                            {
                              "x": 131,
                              "y": 43
                            },
                            {
                              "x": 274,
                              "y": 43
                            },
                            {
                              "x": 274,
                              "y": 53
                            },
                            {
                              "x": 131,
                              "y": 53
                            }
                          ]
                        },
                        "symbols": [
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 131,
                                  "y": 43
                                },
                                {
                                  "x": 164,
                                  "y": 43
                                },
                                {
                                  "x": 164,
                                  "y": 53
                                },
                                {
                                  "x": 131,
                                  "y": 53
                                }
                              ]
                            },
                            "text": "P"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 165,
                                  "y": 43
                                },
                                {
                                  "x": 175,
                                  "y": 43
                                },
                                {
                                  "x": 175,
                                  "y": 53
                                },
                                {
                                  "x": 165,
                                  "y": 53
                                }
                              ]
                            },
                            "text": "A"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 176,
                                  "y": 43
                                },
                                {
                                  "x": 198,
                                  "y": 43
                                },
                                {
                                  "x": 198,
                                  "y": 53
                                },
                                {
                                  "x": 176,
                                  "y": 53
                                }
                              ]
                            },
                            "text": "S"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 199,
                                  "y": 43
                                },
                                {
                                  "x": 212,
                                  "y": 43
                                },
                                {
                                  "x": 212,
                                  "y": 53
                                },
                                {
                                  "x": 199,
                                  "y": 53
                                }
                              ]
                            },
                            "text": "S"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 213,
                                  "y": 43
                                },
                                {
                                  "x": 226,
                                  "y": 43
                                },
                                {
                                  "x": 226,
                                  "y": 53
                                },
                                {
                                  "x": 213,
                                  "y": 53
                                }
                              ]
                            },
                            "text": "P"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 227,
                                  "y": 43
                                },
                                {
                                  "x": 252,
                                  "y": 43
                                },
                                {
                                  "x": 252,
                                  "y": 53
                                },
                                {
                                  "x": 227,
                                  "y": 53
                                }
                              ]
                            },
                            "text": "O"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 253,
                                  "y": 43
                                },
                                {
                                  "x": 263,
                                  "y": 43
                                },
                                {
                                  "x": 263,
                                  "y": 53
                                },
                                {
                                  "x": 253,
                                  "y": 53
                                }
                              ]
                            },
                            "text": "R"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ],
                              "detectedBreak": {
                                "type": "SPACE"
                              }
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 264,
                                  "y": 43
                                },
                                {
                                  "x": 274,
                                  "y": 43
                                },
                                {
                                  "x": 274,
                                  "y": 53
                                },
                                {
                                  "x": 264,
                                  "y": 53
                                }
                              ]
                            },
                            "text": "T"
                          }
                        ]
                      },
                      {
                        "property": {
                          "detectedLanguages": [
                            {
                              "languageCode": "en"
                            }
                          ]
                        },
                        "boundingBox": {
                          "vertices": [
                            {
                              "x": 290,
                              "y": 39
                            },
                            {
                              "x": 359,
                              "y": 39
                            },
                            {
                              "x": 359,
                              "y": 55
                            },
                            {
                              "x": 290,
                              "y": 55
                            }
                          ]
                        },
                        "symbols": [
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 290,
                                  "y": 39
                                },
                                {
                                  "x": 305,
                                  "y": 39
                                },
                                {
                                  "x": 305,
                                  "y": 55
                                },
                                {
                                  "x": 290,
                                  "y": 55
                                }
                              ]
                            },
                            "text": "C"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 306,
                                  "y": 39
                                },
                                {
                                  "x": 314,
                                  "y": 39
                                },
                                {
                                  "x": 314,
                                  "y": 55
                                },
                                {
                                  "x": 306,
                                  "y": 55
                                }
                              ]
                            },
                            "text": "A"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 315,
                                  "y": 39
                                },
                                {
                                  "x": 331,
                                  "y": 39
                                },
                                {
                                  "x": 331,
                                  "y": 55
                                },
                                {
                                  "x": 315,
                                  "y": 55
                                }
                              ]
                            },
                            "text": "R"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ],
                              "detectedBreak": {
                                "type": "EOL_SURE_SPACE"
                              }
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 332,
                                  "y": 39
                                },
                                {
                                  "x": 359,
                                  "y": 39
                                },
                                {
                                  "x": 359,
                                  "y": 55
                                },
                                {
                                  "x": 332,
                                  "y": 55
                                }
                              ]
                            },
                            "text": "D"
                          }
                        ]
                      }
                    ]
                  }
                ],
                "blockType": "TEXT"
              },
              {
                "property": {
                  "detectedLanguages": [
                    {
                      "languageCode": "en",
                      "confidence": 1
                    }
                  ]
                },
                "boundingBox": {
                  "vertices": [
                    {
                      "x": 347,
                      "y": 58
                    },
                    {
                      "x": 455,
                      "y": 58
                    },
                    {
                      "x": 455,
                      "y": 88
                    },
                    {
                      "x": 347,
                      "y": 88
                    }
                  ]
                },
                "paragraphs": [
                  {
                    "property": {
                      "detectedLanguages": [
                        {
                          "languageCode": "en",
                          "confidence": 1
                        }
                      ]
                    },
                    "boundingBox": {
                      "vertices": [
                        {
                          "x": 347,
                          "y": 58
                        },
                        {
                          "x": 455,
                          "y": 58
                        },
                        {
                          "x": 455,
                          "y": 88
                        },
                        {
                          "x": 347,
                          "y": 88
                        }
                      ]
                    },
                    "words": [
                      {
                        "property": {
                          "detectedLanguages": [
                            {
                              "languageCode": "en"
                            }
                          ]
                        },
                        "boundingBox": {
                          "vertices": [
                            {
                              "x": 348,
                              "y": 60
                            },
                            {
                              "x": 401,
                              "y": 60
                            },
                            {
                              "x": 401,
                              "y": 73
                            },
                            {
                              "x": 348,
                              "y": 73
                            }
                          ]
                        },
                        "symbols": [
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 348,
                                  "y": 60
                                },
                                {
                                  "x": 355,
                                  "y": 60
                                },
                                {
                                  "x": 355,
                                  "y": 73
                                },
                                {
                                  "x": 348,
                                  "y": 73
                                }
                              ]
                            },
                            "text": "P"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 356,
                                  "y": 60
                                },
                                {
                                  "x": 360,
                                  "y": 60
                                },
                                {
                                  "x": 360,
                                  "y": 73
                                },
                                {
                                  "x": 356,
                                  "y": 73
                                }
                              ]
                            },
                            "text": "a"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 361,
                                  "y": 60
                                },
                                {
                                  "x": 368,
                                  "y": 60
                                },
                                {
                                  "x": 368,
                                  "y": 73
                                },
                                {
                                  "x": 361,
                                  "y": 73
                                }
                              ]
                            },
                            "text": "s"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 369,
                                  "y": 60
                                },
                                {
                                  "x": 375,
                                  "y": 60
                                },
                                {
                                  "x": 375,
                                  "y": 73
                                },
                                {
                                  "x": 369,
                                  "y": 73
                                }
                              ]
                            },
                            "text": "s"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 376,
                                  "y": 60
                                },
                                {
                                  "x": 383,
                                  "y": 60
                                },
                                {
                                  "x": 383,
                                  "y": 73
                                },
                                {
                                  "x": 376,
                                  "y": 73
                                }
                              ]
                            },
                            "text": "p"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 384,
                                  "y": 60
                                },
                                {
                                  "x": 390,
                                  "y": 60
                                },
                                {
                                  "x": 390,
                                  "y": 73
                                },
                                {
                                  "x": 384,
                                  "y": 73
                                }
                              ]
                            },
                            "text": "o"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 391,
                                  "y": 60
                                },
                                {
                                  "x": 395,
                                  "y": 60
                                },
                                {
                                  "x": 395,
                                  "y": 73
                                },
                                {
                                  "x": 391,
                                  "y": 73
                                }
                              ]
                            },
                            "text": "r"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ],
                              "detectedBreak": {
                                "type": "SPACE"
                              }
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 396,
                                  "y": 60
                                },
                                {
                                  "x": 401,
                                  "y": 60
                                },
                                {
                                  "x": 401,
                                  "y": 73
                                },
                                {
                                  "x": 396,
                                  "y": 73
                                }
                              ]
                            },
                            "text": "t"
                          }
                        ]
                      },
                      {
                        "property": {
                          "detectedLanguages": [
                            {
                              "languageCode": "en"
                            }
                          ]
                        },
                        "boundingBox": {
                          "vertices": [
                            {
                              "x": 406,
                              "y": 60
                            },
                            {
                              "x": 433,
                              "y": 60
                            },
                            {
                              "x": 433,
                              "y": 72
                            },
                            {
                              "x": 406,
                              "y": 72
                            }
                          ]
                        },
                        "symbols": [
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 406,
                                  "y": 60
                                },
                                {
                                  "x": 413,
                                  "y": 60
                                },
                                {
                                  "x": 413,
                                  "y": 69
                                },
                                {
                                  "x": 406,
                                  "y": 69
                                }
                              ]
                            },
                            "text": "C"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 415,
                                  "y": 62
                                },
                                {
                                  "x": 420,
                                  "y": 62
                                },
                                {
                                  "x": 420,
                                  "y": 69
                                },
                                {
                                  "x": 415,
                                  "y": 69
                                }
                              ]
                            },
                            "text": "a"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 423,
                                  "y": 63
                                },
                                {
                                  "x": 425,
                                  "y": 63
                                },
                                {
                                  "x": 425,
                                  "y": 69
                                },
                                {
                                  "x": 423,
                                  "y": 69
                                }
                              ]
                            },
                            "text": "r"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ],
                              "detectedBreak": {
                                "type": "SPACE"
                              }
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 427,
                                  "y": 61
                                },
                                {
                                  "x": 433,
                                  "y": 61
                                },
                                {
                                  "x": 433,
                                  "y": 72
                                },
                                {
                                  "x": 427,
                                  "y": 72
                                }
                              ]
                            },
                            "text": "d"
                          }
                        ]
                      },
                      {
                        "property": {
                          "detectedLanguages": [
                            {
                              "languageCode": "en"
                            }
                          ]
                        },
                        "boundingBox": {
                          "vertices": [
                            {
                              "x": 437,
                              "y": 58
                            },
                            {
                              "x": 455,
                              "y": 58
                            },
                            {
                              "x": 455,
                              "y": 72
                            },
                            {
                              "x": 437,
                              "y": 72
                            }
                          ]
                        },
                        "symbols": [
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 437,
                                  "y": 58
                                },
                                {
                                  "x": 445,
                                  "y": 58
                                },
                                {
                                  "x": 445,
                                  "y": 72
                                },
                                {
                                  "x": 437,
                                  "y": 72
                                }
                              ]
                            },
                            "text": "N"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 446,
                                  "y": 58
                                },
                                {
                                  "x": 453,
                                  "y": 58
                                },
                                {
                                  "x": 453,
                                  "y": 72
                                },
                                {
                                  "x": 446,
                                  "y": 72
                                }
                              ]
                            },
                            "text": "o"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ],
                              "detectedBreak": {
                                "type": "EOL_SURE_SPACE"
                              }
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 454,
                                  "y": 58
                                },
                                {
                                  "x": 455,
                                  "y": 58
                                },
                                {
                                  "x": 455,
                                  "y": 72
                                },
                                {
                                  "x": 454,
                                  "y": 72
                                }
                              ]
                            },
                            "text": "."
                          }
                        ]
                      },
                      {
                        "property": {
                          "detectedLanguages": [
                            {
                              "languageCode": "en"
                            }
                          ]
                        },
                        "boundingBox": {
                          "vertices": [
                            {
                              "x": 347,
                              "y": 71
                            },
                            {
                              "x": 442,
                              "y": 71
                            },
                            {
                              "x": 442,
                              "y": 87
                            },
                            {
                              "x": 347,
                              "y": 87
                            }
                          ]
                        },
                        "symbols": [
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 347,
                                  "y": 73
                                },
                                {
                                  "x": 358,
                                  "y": 73
                                },
                                {
                                  "x": 358,
                                  "y": 87
                                },
                                {
                                  "x": 347,
                                  "y": 87
                                }
                              ]
                            },
                            "text": "C"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 361,
                                  "y": 74
                                },
                                {
                                  "x": 369,
                                  "y": 74
                                },
                                {
                                  "x": 369,
                                  "y": 87
                                },
                                {
                                  "x": 361,
                                  "y": 87
                                }
                              ]
                            },
                            "text": "0"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 371,
                                  "y": 71
                                },
                                {
                                  "x": 379,
                                  "y": 71
                                },
                                {
                                  "x": 379,
                                  "y": 86
                                },
                                {
                                  "x": 371,
                                  "y": 86
                                }
                              ]
                            },
                            "text": "0"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 382,
                                  "y": 73
                                },
                                {
                                  "x": 390,
                                  "y": 73
                                },
                                {
                                  "x": 390,
                                  "y": 86
                                },
                                {
                                  "x": 382,
                                  "y": 86
                                }
                              ]
                            },
                            "text": "0"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 392,
                                  "y": 73
                                },
                                {
                                  "x": 400,
                                  "y": 73
                                },
                                {
                                  "x": 400,
                                  "y": 86
                                },
                                {
                                  "x": 392,
                                  "y": 86
                                }
                              ]
                            },
                            "text": "0"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 403,
                                  "y": 73
                                },
                                {
                                  "x": 411,
                                  "y": 73
                                },
                                {
                                  "x": 411,
                                  "y": 87
                                },
                                {
                                  "x": 403,
                                  "y": 87
                                }
                              ]
                            },
                            "text": "3"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 413,
                                  "y": 73
                                },
                                {
                                  "x": 421,
                                  "y": 73
                                },
                                {
                                  "x": 421,
                                  "y": 86
                                },
                                {
                                  "x": 413,
                                  "y": 86
                                }
                              ]
                            },
                            "text": "5"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 423,
                                  "y": 72
                                },
                                {
                                  "x": 431,
                                  "y": 72
                                },
                                {
                                  "x": 431,
                                  "y": 86
                                },
                                {
                                  "x": 423,
                                  "y": 86
                                }
                              ]
                            },
                            "text": "9"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ],
                              "detectedBreak": {
                                "type": "EOL_SURE_SPACE"
                              }
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 433,
                                  "y": 73
                                },
                                {
                                  "x": 442,
                                  "y": 73
                                },
                                {
                                  "x": 442,
                                  "y": 86
                                },
                                {
                                  "x": 433,
                                  "y": 86
                                }
                              ]
                            },
                            "text": "4"
                          }
                        ]
                      }
                    ]
                  }
                ],
                "blockType": "TEXT"
              },
              {
                "property": {
                  "detectedLanguages": [
                    {
                      "languageCode": "en",
                      "confidence": 0.79
                    }
                  ]
                },
                "boundingBox": {
                  "vertices": [
                    {
                      "x": 223,
                      "y": 78
                    },
                    {
                      "x": 278,
                      "y": 78
                    },
                    {
                      "x": 278,
                      "y": 103
                    },
                    {
                      "x": 223,
                      "y": 103
                    }
                  ]
                },
                "paragraphs": [
                  {
                    "property": {
                      "detectedLanguages": [
                        {
                          "languageCode": "en",
                          "confidence": 0.79
                        }
                      ]
                    },
                    "boundingBox": {
                      "vertices": [
                        {
                          "x": 223,
                          "y": 78
                        },
                        {
                          "x": 278,
                          "y": 78
                        },
                        {
                          "x": 278,
                          "y": 103
                        },
                        {
                          "x": 223,
                          "y": 103
                        }
                      ]
                    },
                    "words": [
                      {
                        "property": {
                          "detectedLanguages": [
                            {
                              "languageCode": "en"
                            }
                          ]
                        },
                        "boundingBox": {
                          "vertices": [
                            {
                              "x": 223,
                              "y": 78
                            },
                            {
                              "x": 278,
                              "y": 79
                            },
                            {
                              "x": 278,
                              "y": 92
                            },
                            {
                              "x": 223,
                              "y": 91
                            }
                          ]
                        },
                        "symbols": [
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 223,
                                  "y": 78
                                },
                                {
                                  "x": 229,
                                  "y": 78
                                },
                                {
                                  "x": 229,
                                  "y": 90
                                },
                                {
                                  "x": 223,
                                  "y": 90
                                }
                              ]
                            },
                            "text": "N"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 230,
                                  "y": 78
                                },
                                {
                                  "x": 234,
                                  "y": 78
                                },
                                {
                                  "x": 234,
                                  "y": 90
                                },
                                {
                                  "x": 230,
                                  "y": 90
                                }
                              ]
                            },
                            "text": "a"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 235,
                                  "y": 78
                                },
                                {
                                  "x": 239,
                                  "y": 78
                                },
                                {
                                  "x": 239,
                                  "y": 90
                                },
                                {
                                  "x": 235,
                                  "y": 90
                                }
                              ]
                            },
                            "text": "t"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 240,
                                  "y": 78
                                },
                                {
                                  "x": 244,
                                  "y": 78
                                },
                                {
                                  "x": 244,
                                  "y": 90
                                },
                                {
                                  "x": 240,
                                  "y": 90
                                }
                              ]
                            },
                            "text": "i"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 245,
                                  "y": 78
                                },
                                {
                                  "x": 249,
                                  "y": 78
                                },
                                {
                                  "x": 249,
                                  "y": 90
                                },
                                {
                                  "x": 245,
                                  "y": 90
                                }
                              ]
                            },
                            "text": "o"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 250,
                                  "y": 79
                                },
                                {
                                  "x": 254,
                                  "y": 79
                                },
                                {
                                  "x": 254,
                                  "y": 91
                                },
                                {
                                  "x": 250,
                                  "y": 91
                                }
                              ]
                            },
                            "text": "n"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 255,
                                  "y": 79
                                },
                                {
                                  "x": 259,
                                  "y": 79
                                },
                                {
                                  "x": 259,
                                  "y": 91
                                },
                                {
                                  "x": 255,
                                  "y": 91
                                }
                              ]
                            },
                            "text": "a"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 260,
                                  "y": 79
                                },
                                {
                                  "x": 264,
                                  "y": 79
                                },
                                {
                                  "x": 264,
                                  "y": 91
                                },
                                {
                                  "x": 260,
                                  "y": 91
                                }
                              ]
                            },
                            "text": "l"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 265,
                                  "y": 79
                                },
                                {
                                  "x": 269,
                                  "y": 79
                                },
                                {
                                  "x": 269,
                                  "y": 91
                                },
                                {
                                  "x": 265,
                                  "y": 91
                                }
                              ]
                            },
                            "text": "i"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 270,
                                  "y": 79
                                },
                                {
                                  "x": 271,
                                  "y": 79
                                },
                                {
                                  "x": 271,
                                  "y": 91
                                },
                                {
                                  "x": 270,
                                  "y": 91
                                }
                              ]
                            },
                            "text": "t"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ],
                              "detectedBreak": {
                                "type": "EOL_SURE_SPACE"
                              }
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 272,
                                  "y": 79
                                },
                                {
                                  "x": 278,
                                  "y": 79
                                },
                                {
                                  "x": 278,
                                  "y": 91
                                },
                                {
                                  "x": 272,
                                  "y": 91
                                }
                              ]
                            },
                            "text": "y"
                          }
                        ]
                      },
                      {
                        "boundingBox": {
                          "vertices": [
                            {
                              "x": 223,
                              "y": 91
                            },
                            {
                              "x": 252,
                              "y": 91
                            },
                            {
                              "x": 252,
                              "y": 103
                            },
                            {
                              "x": 223,
                              "y": 103
                            }
                          ]
                        },
                        "symbols": [
                          {
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 223,
                                  "y": 91
                                },
                                {
                                  "x": 231,
                                  "y": 91
                                },
                                {
                                  "x": 231,
                                  "y": 102
                                },
                                {
                                  "x": 223,
                                  "y": 102
                                }
                              ]
                            },
                            "text": "U"
                          },
                          {
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 233,
                                  "y": 91
                                },
                                {
                                  "x": 241,
                                  "y": 91
                                },
                                {
                                  "x": 241,
                                  "y": 103
                                },
                                {
                                  "x": 233,
                                  "y": 103
                                }
                              ]
                            },
                            "text": "S"
                          },
                          {
                            "property": {
                              "detectedBreak": {
                                "type": "EOL_SURE_SPACE"
                              }
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 243,
                                  "y": 91
                                },
                                {
                                  "x": 252,
                                  "y": 91
                                },
                                {
                                  "x": 252,
                                  "y": 102
                                },
                                {
                                  "x": 243,
                                  "y": 102
                                }
                              ]
                            },
                            "text": "A"
                          }
                        ]
                      }
                    ]
                  }
                ],
                "blockType": "TEXT"
              },
              {
                "property": {
                  "detectedLanguages": [
                    {
                      "languageCode": "en",
                      "confidence": 1
                    }
                  ]
                },
                "boundingBox": {
                  "vertices": [
                    {
                      "x": 222,
                      "y": 113
                    },
                    {
                      "x": 299,
                      "y": 114
                    },
                    {
                      "x": 299,
                      "y": 138
                    },
                    {
                      "x": 222,
                      "y": 137
                    }
                  ]
                },
                "paragraphs": [
                  {
                    "property": {
                      "detectedLanguages": [
                        {
                          "languageCode": "en",
                          "confidence": 1
                        }
                      ]
                    },
                    "boundingBox": {
                      "vertices": [
                        {
                          "x": 222,
                          "y": 113
                        },
                        {
                          "x": 299,
                          "y": 114
                        },
                        {
                          "x": 299,
                          "y": 138
                        },
                        {
                          "x": 222,
                          "y": 137
                        }
                      ]
                    },
                    "words": [
                      {
                        "property": {
                          "detectedLanguages": [
                            {
                              "languageCode": "en"
                            }
                          ]
                        },
                        "boundingBox": {
                          "vertices": [
                            {
                              "x": 223,
                              "y": 113
                            },
                            {
                              "x": 269,
                              "y": 114
                            },
                            {
                              "x": 269,
                              "y": 123
                            },
                            {
                              "x": 223,
                              "y": 122
                            }
                          ]
                        },
                        "symbols": [
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 223,
                                  "y": 113
                                },
                                {
                                  "x": 231,
                                  "y": 113
                                },
                                {
                                  "x": 231,
                                  "y": 121
                                },
                                {
                                  "x": 223,
                                  "y": 121
                                }
                              ]
                            },
                            "text": "S"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 232,
                                  "y": 113
                                },
                                {
                                  "x": 235,
                                  "y": 113
                                },
                                {
                                  "x": 235,
                                  "y": 121
                                },
                                {
                                  "x": 232,
                                  "y": 121
                                }
                              ]
                            },
                            "text": "u"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 236,
                                  "y": 113
                                },
                                {
                                  "x": 240,
                                  "y": 113
                                },
                                {
                                  "x": 240,
                                  "y": 121
                                },
                                {
                                  "x": 236,
                                  "y": 121
                                }
                              ]
                            },
                            "text": "r"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 241,
                                  "y": 113
                                },
                                {
                                  "x": 246,
                                  "y": 113
                                },
                                {
                                  "x": 246,
                                  "y": 121
                                },
                                {
                                  "x": 241,
                                  "y": 121
                                }
                              ]
                            },
                            "text": "n"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 247,
                                  "y": 113
                                },
                                {
                                  "x": 251,
                                  "y": 113
                                },
                                {
                                  "x": 251,
                                  "y": 121
                                },
                                {
                                  "x": 247,
                                  "y": 121
                                }
                              ]
                            },
                            "text": "a"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 252,
                                  "y": 113
                                },
                                {
                                  "x": 261,
                                  "y": 113
                                },
                                {
                                  "x": 261,
                                  "y": 121
                                },
                                {
                                  "x": 252,
                                  "y": 121
                                }
                              ]
                            },
                            "text": "m"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ],
                              "detectedBreak": {
                                "type": "EOL_SURE_SPACE"
                              }
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 262,
                                  "y": 114
                                },
                                {
                                  "x": 269,
                                  "y": 114
                                },
                                {
                                  "x": 269,
                                  "y": 122
                                },
                                {
                                  "x": 262,
                                  "y": 122
                                }
                              ]
                            },
                            "text": "e"
                          }
                        ]
                      },
                      {
                        "property": {
                          "detectedLanguages": [
                            {
                              "languageCode": "en"
                            }
                          ]
                        },
                        "boundingBox": {
                          "vertices": [
                            {
                              "x": 222,
                              "y": 125
                            },
                            {
                              "x": 299,
                              "y": 126
                            },
                            {
                              "x": 299,
                              "y": 138
                            },
                            {
                              "x": 222,
                              "y": 137
                            }
                          ]
                        },
                        "symbols": [
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 222,
                                  "y": 125
                                },
                                {
                                  "x": 230,
                                  "y": 125
                                },
                                {
                                  "x": 230,
                                  "y": 137
                                },
                                {
                                  "x": 222,
                                  "y": 137
                                }
                              ]
                            },
                            "text": "T"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 232,
                                  "y": 125
                                },
                                {
                                  "x": 240,
                                  "y": 125
                                },
                                {
                                  "x": 240,
                                  "y": 137
                                },
                                {
                                  "x": 232,
                                  "y": 137
                                }
                              ]
                            },
                            "text": "R"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 242,
                                  "y": 126
                                },
                                {
                                  "x": 251,
                                  "y": 126
                                },
                                {
                                  "x": 251,
                                  "y": 137
                                },
                                {
                                  "x": 242,
                                  "y": 137
                                }
                              ]
                            },
                            "text": "A"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 253,
                                  "y": 125
                                },
                                {
                                  "x": 260,
                                  "y": 125
                                },
                                {
                                  "x": 260,
                                  "y": 136
                                },
                                {
                                  "x": 253,
                                  "y": 136
                                }
                              ]
                            },
                            "text": "V"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 263,
                                  "y": 126
                                },
                                {
                                  "x": 270,
                                  "y": 126
                                },
                                {
                                  "x": 270,
                                  "y": 137
                                },
                                {
                                  "x": 263,
                                  "y": 137
                                }
                              ]
                            },
                            "text": "E"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 273,
                                  "y": 126
                                },
                                {
                                  "x": 280,
                                  "y": 126
                                },
                                {
                                  "x": 280,
                                  "y": 137
                                },
                                {
                                  "x": 273,
                                  "y": 137
                                }
                              ]
                            },
                            "text": "L"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 283,
                                  "y": 126
                                },
                                {
                                  "x": 290,
                                  "y": 126
                                },
                                {
                                  "x": 290,
                                  "y": 137
                                },
                                {
                                  "x": 283,
                                  "y": 137
                                }
                              ]
                            },
                            "text": "E"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ],
                              "detectedBreak": {
                                "type": "EOL_SURE_SPACE"
                              }
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 292,
                                  "y": 126
                                },
                                {
                                  "x": 299,
                                  "y": 126
                                },
                                {
                                  "x": 299,
                                  "y": 137
                                },
                                {
                                  "x": 292,
                                  "y": 137
                                }
                              ]
                            },
                            "text": "R"
                          }
                        ]
                      }
                    ]
                  }
                ],
                "blockType": "TEXT"
              },
              {
                "property": {
                  "detectedLanguages": [
                    {
                      "languageCode": "en",
                      "confidence": 1
                    }
                  ]
                },
                "boundingBox": {
                  "vertices": [
                    {
                      "x": 220,
                      "y": 147
                    },
                    {
                      "x": 292,
                      "y": 147
                    },
                    {
                      "x": 292,
                      "y": 156
                    },
                    {
                      "x": 220,
                      "y": 156
                    }
                  ]
                },
                "paragraphs": [
                  {
                    "property": {
                      "detectedLanguages": [
                        {
                          "languageCode": "en",
                          "confidence": 1
                        }
                      ]
                    },
                    "boundingBox": {
                      "vertices": [
                        {
                          "x": 220,
                          "y": 147
                        },
                        {
                          "x": 292,
                          "y": 147
                        },
                        {
                          "x": 292,
                          "y": 156
                        },
                        {
                          "x": 220,
                          "y": 156
                        }
                      ]
                    },
                    "words": [
                      {
                        "property": {
                          "detectedLanguages": [
                            {
                              "languageCode": "en"
                            }
                          ]
                        },
                        "boundingBox": {
                          "vertices": [
                            {
                              "x": 220,
                              "y": 147
                            },
                            {
                              "x": 252,
                              "y": 147
                            },
                            {
                              "x": 252,
                              "y": 156
                            },
                            {
                              "x": 220,
                              "y": 156
                            }
                          ]
                        },
                        "symbols": [
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 220,
                                  "y": 147
                                },
                                {
                                  "x": 231,
                                  "y": 147
                                },
                                {
                                  "x": 231,
                                  "y": 156
                                },
                                {
                                  "x": 220,
                                  "y": 156
                                }
                              ]
                            },
                            "text": "G"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 232,
                                  "y": 147
                                },
                                {
                                  "x": 235,
                                  "y": 147
                                },
                                {
                                  "x": 235,
                                  "y": 156
                                },
                                {
                                  "x": 232,
                                  "y": 156
                                }
                              ]
                            },
                            "text": "i"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 236,
                                  "y": 147
                                },
                                {
                                  "x": 241,
                                  "y": 147
                                },
                                {
                                  "x": 241,
                                  "y": 156
                                },
                                {
                                  "x": 236,
                                  "y": 156
                                }
                              ]
                            },
                            "text": "v"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 242,
                                  "y": 147
                                },
                                {
                                  "x": 245,
                                  "y": 147
                                },
                                {
                                  "x": 245,
                                  "y": 156
                                },
                                {
                                  "x": 242,
                                  "y": 156
                                }
                              ]
                            },
                            "text": "e"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ],
                              "detectedBreak": {
                                "type": "SPACE"
                              }
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 246,
                                  "y": 147
                                },
                                {
                                  "x": 252,
                                  "y": 147
                                },
                                {
                                  "x": 252,
                                  "y": 156
                                },
                                {
                                  "x": 246,
                                  "y": 156
                                }
                              ]
                            },
                            "text": "n"
                          }
                        ]
                      },
                      {
                        "property": {
                          "detectedLanguages": [
                            {
                              "languageCode": "en"
                            }
                          ]
                        },
                        "boundingBox": {
                          "vertices": [
                            {
                              "x": 258,
                              "y": 147
                            },
                            {
                              "x": 292,
                              "y": 147
                            },
                            {
                              "x": 292,
                              "y": 155
                            },
                            {
                              "x": 258,
                              "y": 155
                            }
                          ]
                        },
                        "symbols": [
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 258,
                                  "y": 147
                                },
                                {
                                  "x": 263,
                                  "y": 147
                                },
                                {
                                  "x": 263,
                                  "y": 155
                                },
                                {
                                  "x": 258,
                                  "y": 155
                                }
                              ]
                            },
                            "text": "N"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 264,
                                  "y": 147
                                },
                                {
                                  "x": 269,
                                  "y": 147
                                },
                                {
                                  "x": 269,
                                  "y": 155
                                },
                                {
                                  "x": 264,
                                  "y": 155
                                }
                              ]
                            },
                            "text": "a"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 270,
                                  "y": 147
                                },
                                {
                                  "x": 279,
                                  "y": 147
                                },
                                {
                                  "x": 279,
                                  "y": 155
                                },
                                {
                                  "x": 270,
                                  "y": 155
                                }
                              ]
                            },
                            "text": "m"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 280,
                                  "y": 147
                                },
                                {
                                  "x": 285,
                                  "y": 147
                                },
                                {
                                  "x": 285,
                                  "y": 155
                                },
                                {
                                  "x": 280,
                                  "y": 155
                                }
                              ]
                            },
                            "text": "e"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ],
                              "detectedBreak": {
                                "type": "EOL_SURE_SPACE"
                              }
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 286,
                                  "y": 147
                                },
                                {
                                  "x": 292,
                                  "y": 147
                                },
                                {
                                  "x": 292,
                                  "y": 155
                                },
                                {
                                  "x": 286,
                                  "y": 155
                                }
                              ]
                            },
                            "text": "s"
                          }
                        ]
                      }
                    ]
                  }
                ],
                "blockType": "TEXT"
              },
              {
                "property": {
                  "detectedLanguages": [
                    {
                      "languageCode": "en",
                      "confidence": 1
                    }
                  ]
                },
                "boundingBox": {
                  "vertices": [
                    {
                      "x": 217,
                      "y": 155
                    },
                    {
                      "x": 272,
                      "y": 155
                    },
                    {
                      "x": 272,
                      "y": 172
                    },
                    {
                      "x": 217,
                      "y": 172
                    }
                  ]
                },
                "paragraphs": [
                  {
                    "property": {
                      "detectedLanguages": [
                        {
                          "languageCode": "en",
                          "confidence": 1
                        }
                      ]
                    },
                    "boundingBox": {
                      "vertices": [
                        {
                          "x": 217,
                          "y": 155
                        },
                        {
                          "x": 272,
                          "y": 155
                        },
                        {
                          "x": 272,
                          "y": 172
                        },
                        {
                          "x": 217,
                          "y": 172
                        }
                      ]
                    },
                    "words": [
                      {
                        "property": {
                          "detectedLanguages": [
                            {
                              "languageCode": "en"
                            }
                          ]
                        },
                        "boundingBox": {
                          "vertices": [
                            {
                              "x": 217,
                              "y": 155
                            },
                            {
                              "x": 272,
                              "y": 155
                            },
                            {
                              "x": 272,
                              "y": 172
                            },
                            {
                              "x": 217,
                              "y": 172
                            }
                          ]
                        },
                        "symbols": [
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 217,
                                  "y": 155
                                },
                                {
                                  "x": 232,
                                  "y": 155
                                },
                                {
                                  "x": 232,
                                  "y": 172
                                },
                                {
                                  "x": 217,
                                  "y": 172
                                }
                              ]
                            },
                            "text": "H"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 233,
                                  "y": 155
                                },
                                {
                                  "x": 244,
                                  "y": 155
                                },
                                {
                                  "x": 244,
                                  "y": 172
                                },
                                {
                                  "x": 233,
                                  "y": 172
                                }
                              ]
                            },
                            "text": "A"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 245,
                                  "y": 155
                                },
                                {
                                  "x": 253,
                                  "y": 155
                                },
                                {
                                  "x": 253,
                                  "y": 172
                                },
                                {
                                  "x": 245,
                                  "y": 172
                                }
                              ]
                            },
                            "text": "P"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 254,
                                  "y": 155
                                },
                                {
                                  "x": 265,
                                  "y": 155
                                },
                                {
                                  "x": 265,
                                  "y": 172
                                },
                                {
                                  "x": 254,
                                  "y": 172
                                }
                              ]
                            },
                            "text": "P"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ],
                              "detectedBreak": {
                                "type": "EOL_SURE_SPACE"
                              }
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 266,
                                  "y": 155
                                },
                                {
                                  "x": 272,
                                  "y": 155
                                },
                                {
                                  "x": 272,
                                  "y": 172
                                },
                                {
                                  "x": 266,
                                  "y": 172
                                }
                              ]
                            },
                            "text": "Y"
                          }
                        ]
                      }
                    ]
                  }
                ],
                "blockType": "TEXT"
              },
              {
                "boundingBox": {
                  "vertices": [
                    {
                      "x": 223,
                      "y": 179
                    },
                    {
                      "x": 240,
                      "y": 179
                    },
                    {
                      "x": 240,
                      "y": 190
                    },
                    {
                      "x": 223,
                      "y": 190
                    }
                  ]
                },
                "paragraphs": [
                  {
                    "boundingBox": {
                      "vertices": [
                        {
                          "x": 223,
                          "y": 179
                        },
                        {
                          "x": 240,
                          "y": 179
                        },
                        {
                          "x": 240,
                          "y": 190
                        },
                        {
                          "x": 223,
                          "y": 190
                        }
                      ]
                    },
                    "words": [
                      {
                        "boundingBox": {
                          "vertices": [
                            {
                              "x": 223,
                              "y": 179
                            },
                            {
                              "x": 240,
                              "y": 179
                            },
                            {
                              "x": 240,
                              "y": 190
                            },
                            {
                              "x": 223,
                              "y": 190
                            }
                          ]
                        },
                        "symbols": [
                          {
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 223,
                                  "y": 179
                                },
                                {
                                  "x": 231,
                                  "y": 179
                                },
                                {
                                  "x": 231,
                                  "y": 190
                                },
                                {
                                  "x": 223,
                                  "y": 190
                                }
                              ]
                            },
                            "text": "S"
                          },
                          {
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 232,
                                  "y": 179
                                },
                                {
                                  "x": 237,
                                  "y": 179
                                },
                                {
                                  "x": 237,
                                  "y": 190
                                },
                                {
                                  "x": 232,
                                  "y": 190
                                }
                              ]
                            },
                            "text": "e"
                          },
                          {
                            "property": {
                              "detectedBreak": {
                                "type": "EOL_SURE_SPACE"
                              }
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 238,
                                  "y": 179
                                },
                                {
                                  "x": 240,
                                  "y": 179
                                },
                                {
                                  "x": 240,
                                  "y": 190
                                },
                                {
                                  "x": 238,
                                  "y": 190
                                }
                              ]
                            },
                            "text": "x"
                          }
                        ]
                      }
                    ]
                  }
                ],
                "blockType": "TEXT"
              },
              {
                "property": {
                  "detectedLanguages": [
                    {
                      "languageCode": "en",
                      "confidence": 1
                    }
                  ]
                },
                "boundingBox": {
                  "vertices": [
                    {
                      "x": 283,
                      "y": 181
                    },
                    {
                      "x": 348,
                      "y": 181
                    },
                    {
                      "x": 348,
                      "y": 188
                    },
                    {
                      "x": 283,
                      "y": 188
                    }
                  ]
                },
                "paragraphs": [
                  {
                    "property": {
                      "detectedLanguages": [
                        {
                          "languageCode": "en",
                          "confidence": 1
                        }
                      ]
                    },
                    "boundingBox": {
                      "vertices": [
                        {
                          "x": 283,
                          "y": 181
                        },
                        {
                          "x": 348,
                          "y": 181
                        },
                        {
                          "x": 348,
                          "y": 188
                        },
                        {
                          "x": 283,
                          "y": 188
                        }
                      ]
                    },
                    "words": [
                      {
                        "property": {
                          "detectedLanguages": [
                            {
                              "languageCode": "en"
                            }
                          ]
                        },
                        "boundingBox": {
                          "vertices": [
                            {
                              "x": 283,
                              "y": 181
                            },
                            {
                              "x": 305,
                              "y": 181
                            },
                            {
                              "x": 305,
                              "y": 188
                            },
                            {
                              "x": 283,
                              "y": 188
                            }
                          ]
                        },
                        "symbols": [
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 283,
                                  "y": 181
                                },
                                {
                                  "x": 289,
                                  "y": 181
                                },
                                {
                                  "x": 289,
                                  "y": 188
                                },
                                {
                                  "x": 283,
                                  "y": 188
                                }
                              ]
                            },
                            "text": "D"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 291,
                                  "y": 183
                                },
                                {
                                  "x": 295,
                                  "y": 183
                                },
                                {
                                  "x": 295,
                                  "y": 188
                                },
                                {
                                  "x": 291,
                                  "y": 188
                                }
                              ]
                            },
                            "text": "a"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 297,
                                  "y": 182
                                },
                                {
                                  "x": 299,
                                  "y": 182
                                },
                                {
                                  "x": 299,
                                  "y": 188
                                },
                                {
                                  "x": 297,
                                  "y": 188
                                }
                              ]
                            },
                            "text": "t"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ],
                              "detectedBreak": {
                                "type": "SPACE"
                              }
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 301,
                                  "y": 183
                                },
                                {
                                  "x": 305,
                                  "y": 183
                                },
                                {
                                  "x": 305,
                                  "y": 188
                                },
                                {
                                  "x": 301,
                                  "y": 188
                                }
                              ]
                            },
                            "text": "e"
                          }
                        ]
                      },
                      {
                        "property": {
                          "detectedLanguages": [
                            {
                              "languageCode": "en"
                            }
                          ]
                        },
                        "boundingBox": {
                          "vertices": [
                            {
                              "x": 311,
                              "y": 181
                            },
                            {
                              "x": 319,
                              "y": 181
                            },
                            {
                              "x": 319,
                              "y": 188
                            },
                            {
                              "x": 311,
                              "y": 188
                            }
                          ]
                        },
                        "symbols": [
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 311,
                                  "y": 183
                                },
                                {
                                  "x": 316,
                                  "y": 183
                                },
                                {
                                  "x": 316,
                                  "y": 188
                                },
                                {
                                  "x": 311,
                                  "y": 188
                                }
                              ]
                            },
                            "text": "o"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ],
                              "detectedBreak": {
                                "type": "SPACE"
                              }
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 318,
                                  "y": 181
                                },
                                {
                                  "x": 319,
                                  "y": 181
                                },
                                {
                                  "x": 319,
                                  "y": 188
                                },
                                {
                                  "x": 318,
                                  "y": 188
                                }
                              ]
                            },
                            "text": "f"
                          }
                        ]
                      },
                      {
                        "property": {
                          "detectedLanguages": [
                            {
                              "languageCode": "en"
                            }
                          ]
                        },
                        "boundingBox": {
                          "vertices": [
                            {
                              "x": 324,
                              "y": 181
                            },
                            {
                              "x": 348,
                              "y": 181
                            },
                            {
                              "x": 348,
                              "y": 188
                            },
                            {
                              "x": 324,
                              "y": 188
                            }
                          ]
                        },
                        "symbols": [
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 324,
                                  "y": 181
                                },
                                {
                                  "x": 330,
                                  "y": 181
                                },
                                {
                                  "x": 330,
                                  "y": 188
                                },
                                {
                                  "x": 324,
                                  "y": 188
                                }
                              ]
                            },
                            "text": "B"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 331,
                                  "y": 181
                                },
                                {
                                  "x": 333,
                                  "y": 181
                                },
                                {
                                  "x": 333,
                                  "y": 188
                                },
                                {
                                  "x": 331,
                                  "y": 188
                                }
                              ]
                            },
                            "text": "i"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 334,
                                  "y": 181
                                },
                                {
                                  "x": 337,
                                  "y": 181
                                },
                                {
                                  "x": 337,
                                  "y": 188
                                },
                                {
                                  "x": 334,
                                  "y": 188
                                }
                              ]
                            },
                            "text": "r"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 338,
                                  "y": 181
                                },
                                {
                                  "x": 341,
                                  "y": 181
                                },
                                {
                                  "x": 341,
                                  "y": 188
                                },
                                {
                                  "x": 338,
                                  "y": 188
                                }
                              ]
                            },
                            "text": "t"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ],
                              "detectedBreak": {
                                "type": "EOL_SURE_SPACE"
                              }
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 342,
                                  "y": 181
                                },
                                {
                                  "x": 348,
                                  "y": 181
                                },
                                {
                                  "x": 348,
                                  "y": 188
                                },
                                {
                                  "x": 342,
                                  "y": 188
                                }
                              ]
                            },
                            "text": "h"
                          }
                        ]
                      }
                    ]
                  }
                ],
                "blockType": "TEXT"
              },
              {
                "property": {
                  "detectedLanguages": [
                    {
                      "languageCode": "en",
                      "confidence": 1
                    }
                  ]
                },
                "boundingBox": {
                  "vertices": [
                    {
                      "x": 283,
                      "y": 192
                    },
                    {
                      "x": 369,
                      "y": 192
                    },
                    {
                      "x": 369,
                      "y": 203
                    },
                    {
                      "x": 283,
                      "y": 203
                    }
                  ]
                },
                "paragraphs": [
                  {
                    "property": {
                      "detectedLanguages": [
                        {
                          "languageCode": "en",
                          "confidence": 1
                        }
                      ]
                    },
                    "boundingBox": {
                      "vertices": [
                        {
                          "x": 283,
                          "y": 192
                        },
                        {
                          "x": 369,
                          "y": 192
                        },
                        {
                          "x": 369,
                          "y": 203
                        },
                        {
                          "x": 283,
                          "y": 203
                        }
                      ]
                    },
                    "words": [
                      {
                        "property": {
                          "detectedLanguages": [
                            {
                              "languageCode": "en"
                            }
                          ]
                        },
                        "boundingBox": {
                          "vertices": [
                            {
                              "x": 283,
                              "y": 192
                            },
                            {
                              "x": 296,
                              "y": 192
                            },
                            {
                              "x": 296,
                              "y": 203
                            },
                            {
                              "x": 283,
                              "y": 203
                            }
                          ]
                        },
                        "symbols": [
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 283,
                                  "y": 192
                                },
                                {
                                  "x": 290,
                                  "y": 192
                                },
                                {
                                  "x": 290,
                                  "y": 203
                                },
                                {
                                  "x": 283,
                                  "y": 203
                                }
                              ]
                            },
                            "text": "0"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ],
                              "detectedBreak": {
                                "type": "SPACE"
                              }
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 293,
                                  "y": 192
                                },
                                {
                                  "x": 296,
                                  "y": 192
                                },
                                {
                                  "x": 296,
                                  "y": 203
                                },
                                {
                                  "x": 293,
                                  "y": 203
                                }
                              ]
                            },
                            "text": "1"
                          }
                        ]
                      },
                      {
                        "property": {
                          "detectedLanguages": [
                            {
                              "languageCode": "en"
                            }
                          ]
                        },
                        "boundingBox": {
                          "vertices": [
                            {
                              "x": 305,
                              "y": 192
                            },
                            {
                              "x": 333,
                              "y": 192
                            },
                            {
                              "x": 333,
                              "y": 203
                            },
                            {
                              "x": 305,
                              "y": 203
                            }
                          ]
                        },
                        "symbols": [
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 305,
                                  "y": 192
                                },
                                {
                                  "x": 313,
                                  "y": 192
                                },
                                {
                                  "x": 313,
                                  "y": 203
                                },
                                {
                                  "x": 305,
                                  "y": 203
                                }
                              ]
                            },
                            "text": "J"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 314,
                                  "y": 192
                                },
                                {
                                  "x": 319,
                                  "y": 192
                                },
                                {
                                  "x": 319,
                                  "y": 203
                                },
                                {
                                  "x": 314,
                                  "y": 203
                                }
                              ]
                            },
                            "text": "A"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ],
                              "detectedBreak": {
                                "type": "SPACE"
                              }
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 320,
                                  "y": 192
                                },
                                {
                                  "x": 333,
                                  "y": 192
                                },
                                {
                                  "x": 333,
                                  "y": 203
                                },
                                {
                                  "x": 320,
                                  "y": 203
                                }
                              ]
                            },
                            "text": "N"
                          }
                        ]
                      },
                      {
                        "property": {
                          "detectedLanguages": [
                            {
                              "languageCode": "en"
                            }
                          ]
                        },
                        "boundingBox": {
                          "vertices": [
                            {
                              "x": 341,
                              "y": 192
                            },
                            {
                              "x": 369,
                              "y": 192
                            },
                            {
                              "x": 369,
                              "y": 203
                            },
                            {
                              "x": 341,
                              "y": 203
                            }
                          ]
                        },
                        "symbols": [
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 341,
                                  "y": 192
                                },
                                {
                                  "x": 346,
                                  "y": 192
                                },
                                {
                                  "x": 346,
                                  "y": 203
                                },
                                {
                                  "x": 341,
                                  "y": 203
                                }
                              ]
                            },
                            "text": "1"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 347,
                                  "y": 192
                                },
                                {
                                  "x": 352,
                                  "y": 192
                                },
                                {
                                  "x": 352,
                                  "y": 203
                                },
                                {
                                  "x": 347,
                                  "y": 203
                                }
                              ]
                            },
                            "text": "9"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 353,
                                  "y": 192
                                },
                                {
                                  "x": 361,
                                  "y": 192
                                },
                                {
                                  "x": 361,
                                  "y": 203
                                },
                                {
                                  "x": 353,
                                  "y": 203
                                }
                              ]
                            },
                            "text": "8"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ],
                              "detectedBreak": {
                                "type": "EOL_SURE_SPACE"
                              }
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 362,
                                  "y": 192
                                },
                                {
                                  "x": 369,
                                  "y": 192
                                },
                                {
                                  "x": 369,
                                  "y": 203
                                },
                                {
                                  "x": 362,
                                  "y": 203
                                }
                              ]
                            },
                            "text": "1"
                          }
                        ]
                      }
                    ]
                  }
                ],
                "blockType": "TEXT"
              },
              {
                "property": {
                  "detectedLanguages": [
                    {
                      "languageCode": "en",
                      "confidence": 1
                    }
                  ]
                },
                "boundingBox": {
                  "vertices": [
                    {
                      "x": 217,
                      "y": 212
                    },
                    {
                      "x": 342,
                      "y": 212
                    },
                    {
                      "x": 342,
                      "y": 240
                    },
                    {
                      "x": 217,
                      "y": 240
                    }
                  ]
                },
                "paragraphs": [
                  {
                    "property": {
                      "detectedLanguages": [
                        {
                          "languageCode": "en",
                          "confidence": 1
                        }
                      ]
                    },
                    "boundingBox": {
                      "vertices": [
                        {
                          "x": 217,
                          "y": 212
                        },
                        {
                          "x": 342,
                          "y": 212
                        },
                        {
                          "x": 342,
                          "y": 240
                        },
                        {
                          "x": 217,
                          "y": 240
                        }
                      ]
                    },
                    "words": [
                      {
                        "property": {
                          "detectedLanguages": [
                            {
                              "languageCode": "en"
                            }
                          ]
                        },
                        "boundingBox": {
                          "vertices": [
                            {
                              "x": 220,
                              "y": 212
                            },
                            {
                              "x": 250,
                              "y": 212
                            },
                            {
                              "x": 250,
                              "y": 224
                            },
                            {
                              "x": 220,
                              "y": 224
                            }
                          ]
                        },
                        "symbols": [
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 220,
                                  "y": 212
                                },
                                {
                                  "x": 229,
                                  "y": 212
                                },
                                {
                                  "x": 229,
                                  "y": 224
                                },
                                {
                                  "x": 220,
                                  "y": 224
                                }
                              ]
                            },
                            "text": "P"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 230,
                                  "y": 212
                                },
                                {
                                  "x": 234,
                                  "y": 212
                                },
                                {
                                  "x": 234,
                                  "y": 224
                                },
                                {
                                  "x": 230,
                                  "y": 224
                                }
                              ]
                            },
                            "text": "l"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 235,
                                  "y": 212
                                },
                                {
                                  "x": 238,
                                  "y": 212
                                },
                                {
                                  "x": 238,
                                  "y": 224
                                },
                                {
                                  "x": 235,
                                  "y": 224
                                }
                              ]
                            },
                            "text": "a"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 239,
                                  "y": 212
                                },
                                {
                                  "x": 245,
                                  "y": 212
                                },
                                {
                                  "x": 245,
                                  "y": 224
                                },
                                {
                                  "x": 239,
                                  "y": 224
                                }
                              ]
                            },
                            "text": "c"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ],
                              "detectedBreak": {
                                "type": "SPACE"
                              }
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 246,
                                  "y": 212
                                },
                                {
                                  "x": 250,
                                  "y": 212
                                },
                                {
                                  "x": 250,
                                  "y": 224
                                },
                                {
                                  "x": 246,
                                  "y": 224
                                }
                              ]
                            },
                            "text": "e"
                          }
                        ]
                      },
                      {
                        "property": {
                          "detectedLanguages": [
                            {
                              "languageCode": "en"
                            }
                          ]
                        },
                        "boundingBox": {
                          "vertices": [
                            {
                              "x": 255,
                              "y": 215
                            },
                            {
                              "x": 264,
                              "y": 215
                            },
                            {
                              "x": 264,
                              "y": 222
                            },
                            {
                              "x": 255,
                              "y": 222
                            }
                          ]
                        },
                        "symbols": [
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 255,
                                  "y": 217
                                },
                                {
                                  "x": 260,
                                  "y": 217
                                },
                                {
                                  "x": 260,
                                  "y": 222
                                },
                                {
                                  "x": 255,
                                  "y": 222
                                }
                              ]
                            },
                            "text": "o"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ],
                              "detectedBreak": {
                                "type": "SPACE"
                              }
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 262,
                                  "y": 215
                                },
                                {
                                  "x": 264,
                                  "y": 215
                                },
                                {
                                  "x": 264,
                                  "y": 222
                                },
                                {
                                  "x": 262,
                                  "y": 222
                                }
                              ]
                            },
                            "text": "f"
                          }
                        ]
                      },
                      {
                        "property": {
                          "detectedLanguages": [
                            {
                              "languageCode": "en"
                            }
                          ]
                        },
                        "boundingBox": {
                          "vertices": [
                            {
                              "x": 269,
                              "y": 215
                            },
                            {
                              "x": 292,
                              "y": 215
                            },
                            {
                              "x": 292,
                              "y": 223
                            },
                            {
                              "x": 269,
                              "y": 223
                            }
                          ]
                        },
                        "symbols": [
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 269,
                                  "y": 215
                                },
                                {
                                  "x": 275,
                                  "y": 215
                                },
                                {
                                  "x": 275,
                                  "y": 223
                                },
                                {
                                  "x": 269,
                                  "y": 223
                                }
                              ]
                            },
                            "text": "B"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 276,
                                  "y": 215
                                },
                                {
                                  "x": 279,
                                  "y": 215
                                },
                                {
                                  "x": 279,
                                  "y": 223
                                },
                                {
                                  "x": 276,
                                  "y": 223
                                }
                              ]
                            },
                            "text": "i"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 280,
                                  "y": 215
                                },
                                {
                                  "x": 281,
                                  "y": 215
                                },
                                {
                                  "x": 281,
                                  "y": 223
                                },
                                {
                                  "x": 280,
                                  "y": 223
                                }
                              ]
                            },
                            "text": "r"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 282,
                                  "y": 215
                                },
                                {
                                  "x": 286,
                                  "y": 215
                                },
                                {
                                  "x": 286,
                                  "y": 223
                                },
                                {
                                  "x": 282,
                                  "y": 223
                                }
                              ]
                            },
                            "text": "t"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ],
                              "detectedBreak": {
                                "type": "EOL_SURE_SPACE"
                              }
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 287,
                                  "y": 215
                                },
                                {
                                  "x": 292,
                                  "y": 215
                                },
                                {
                                  "x": 292,
                                  "y": 223
                                },
                                {
                                  "x": 287,
                                  "y": 223
                                }
                              ]
                            },
                            "text": "h"
                          }
                        ]
                      },
                      {
                        "property": {
                          "detectedLanguages": [
                            {
                              "languageCode": "en"
                            }
                          ]
                        },
                        "boundingBox": {
                          "vertices": [
                            {
                              "x": 217,
                              "y": 224
                            },
                            {
                              "x": 257,
                              "y": 224
                            },
                            {
                              "x": 257,
                              "y": 240
                            },
                            {
                              "x": 217,
                              "y": 240
                            }
                          ]
                        },
                        "symbols": [
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 217,
                                  "y": 224
                                },
                                {
                                  "x": 236,
                                  "y": 224
                                },
                                {
                                  "x": 236,
                                  "y": 240
                                },
                                {
                                  "x": 217,
                                  "y": 240
                                }
                              ]
                            },
                            "text": "N"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 237,
                                  "y": 224
                                },
                                {
                                  "x": 244,
                                  "y": 224
                                },
                                {
                                  "x": 244,
                                  "y": 240
                                },
                                {
                                  "x": 237,
                                  "y": 240
                                }
                              ]
                            },
                            "text": "E"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ],
                              "detectedBreak": {
                                "type": "SPACE"
                              }
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 245,
                                  "y": 224
                                },
                                {
                                  "x": 257,
                                  "y": 224
                                },
                                {
                                  "x": 257,
                                  "y": 240
                                },
                                {
                                  "x": 245,
                                  "y": 240
                                }
                              ]
                            },
                            "text": "W"
                          }
                        ]
                      },
                      {
                        "property": {
                          "detectedLanguages": [
                            {
                              "languageCode": "en"
                            }
                          ]
                        },
                        "boundingBox": {
                          "vertices": [
                            {
                              "x": 264,
                              "y": 226
                            },
                            {
                              "x": 306,
                              "y": 226
                            },
                            {
                              "x": 306,
                              "y": 238
                            },
                            {
                              "x": 264,
                              "y": 238
                            }
                          ]
                        },
                        "symbols": [
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 264,
                                  "y": 227
                                },
                                {
                                  "x": 270,
                                  "y": 227
                                },
                                {
                                  "x": 270,
                                  "y": 237
                                },
                                {
                                  "x": 264,
                                  "y": 237
                                }
                              ]
                            },
                            "text": "Y"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 273,
                                  "y": 226
                                },
                                {
                                  "x": 281,
                                  "y": 226
                                },
                                {
                                  "x": 281,
                                  "y": 237
                                },
                                {
                                  "x": 273,
                                  "y": 237
                                }
                              ]
                            },
                            "text": "O"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 283,
                                  "y": 226
                                },
                                {
                                  "x": 291,
                                  "y": 226
                                },
                                {
                                  "x": 291,
                                  "y": 237
                                },
                                {
                                  "x": 283,
                                  "y": 237
                                }
                              ]
                            },
                            "text": "R"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 294,
                                  "y": 227
                                },
                                {
                                  "x": 302,
                                  "y": 227
                                },
                                {
                                  "x": 302,
                                  "y": 237
                                },
                                {
                                  "x": 294,
                                  "y": 237
                                }
                              ]
                            },
                            "text": "K"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ],
                              "detectedBreak": {
                                "type": "SPACE"
                              }
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 305,
                                  "y": 237
                                },
                                {
                                  "x": 306,
                                  "y": 237
                                },
                                {
                                  "x": 306,
                                  "y": 238
                                },
                                {
                                  "x": 305,
                                  "y": 238
                                }
                              ]
                            },
                            "text": "."
                          }
                        ]
                      },
                      {
                        "property": {
                          "detectedLanguages": [
                            {
                              "languageCode": "en"
                            }
                          ]
                        },
                        "boundingBox": {
                          "vertices": [
                            {
                              "x": 314,
                              "y": 226
                            },
                            {
                              "x": 342,
                              "y": 226
                            },
                            {
                              "x": 342,
                              "y": 237
                            },
                            {
                              "x": 314,
                              "y": 237
                            }
                          ]
                        },
                        "symbols": [
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 314,
                                  "y": 227
                                },
                                {
                                  "x": 321,
                                  "y": 227
                                },
                                {
                                  "x": 321,
                                  "y": 237
                                },
                                {
                                  "x": 314,
                                  "y": 237
                                }
                              ]
                            },
                            "text": "U"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 324,
                                  "y": 226
                                },
                                {
                                  "x": 331,
                                  "y": 226
                                },
                                {
                                  "x": 331,
                                  "y": 237
                                },
                                {
                                  "x": 324,
                                  "y": 237
                                }
                              ]
                            },
                            "text": "S"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ],
                              "detectedBreak": {
                                "type": "EOL_SURE_SPACE"
                              }
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 334,
                                  "y": 227
                                },
                                {
                                  "x": 342,
                                  "y": 227
                                },
                                {
                                  "x": 342,
                                  "y": 237
                                },
                                {
                                  "x": 334,
                                  "y": 237
                                }
                              ]
                            },
                            "text": "A"
                          }
                        ]
                      }
                    ]
                  }
                ],
                "blockType": "TEXT"
              },
              {
                "property": {
                  "detectedLanguages": [
                    {
                      "languageCode": "en",
                      "confidence": 1
                    }
                  ]
                },
                "boundingBox": {
                  "vertices": [
                    {
                      "x": 354,
                      "y": 247
                    },
                    {
                      "x": 427,
                      "y": 247
                    },
                    {
                      "x": 427,
                      "y": 271
                    },
                    {
                      "x": 354,
                      "y": 271
                    }
                  ]
                },
                "paragraphs": [
                  {
                    "property": {
                      "detectedLanguages": [
                        {
                          "languageCode": "en",
                          "confidence": 1
                        }
                      ]
                    },
                    "boundingBox": {
                      "vertices": [
                        {
                          "x": 354,
                          "y": 247
                        },
                        {
                          "x": 427,
                          "y": 247
                        },
                        {
                          "x": 427,
                          "y": 271
                        },
                        {
                          "x": 354,
                          "y": 271
                        }
                      ]
                    },
                    "words": [
                      {
                        "property": {
                          "detectedLanguages": [
                            {
                              "languageCode": "en"
                            }
                          ]
                        },
                        "boundingBox": {
                          "vertices": [
                            {
                              "x": 354,
                              "y": 247
                            },
                            {
                              "x": 392,
                              "y": 246
                            },
                            {
                              "x": 392,
                              "y": 257
                            },
                            {
                              "x": 354,
                              "y": 258
                            }
                          ]
                        },
                        "symbols": [
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 354,
                                  "y": 248
                                },
                                {
                                  "x": 360,
                                  "y": 248
                                },
                                {
                                  "x": 360,
                                  "y": 258
                                },
                                {
                                  "x": 354,
                                  "y": 258
                                }
                              ]
                            },
                            "text": "E"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 361,
                                  "y": 248
                                },
                                {
                                  "x": 366,
                                  "y": 248
                                },
                                {
                                  "x": 366,
                                  "y": 258
                                },
                                {
                                  "x": 361,
                                  "y": 258
                                }
                              ]
                            },
                            "text": "x"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 367,
                                  "y": 248
                                },
                                {
                                  "x": 372,
                                  "y": 248
                                },
                                {
                                  "x": 372,
                                  "y": 258
                                },
                                {
                                  "x": 367,
                                  "y": 258
                                }
                              ]
                            },
                            "text": "p"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 373,
                                  "y": 248
                                },
                                {
                                  "x": 378,
                                  "y": 248
                                },
                                {
                                  "x": 378,
                                  "y": 258
                                },
                                {
                                  "x": 373,
                                  "y": 258
                                }
                              ]
                            },
                            "text": "i"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 379,
                                  "y": 248
                                },
                                {
                                  "x": 382,
                                  "y": 248
                                },
                                {
                                  "x": 382,
                                  "y": 258
                                },
                                {
                                  "x": 379,
                                  "y": 258
                                }
                              ]
                            },
                            "text": "r"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 383,
                                  "y": 248
                                },
                                {
                                  "x": 386,
                                  "y": 248
                                },
                                {
                                  "x": 386,
                                  "y": 258
                                },
                                {
                                  "x": 383,
                                  "y": 258
                                }
                              ]
                            },
                            "text": "e"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ],
                              "detectedBreak": {
                                "type": "SPACE"
                              }
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 387,
                                  "y": 247
                                },
                                {
                                  "x": 392,
                                  "y": 247
                                },
                                {
                                  "x": 392,
                                  "y": 257
                                },
                                {
                                  "x": 387,
                                  "y": 257
                                }
                              ]
                            },
                            "text": "s"
                          }
                        ]
                      },
                      {
                        "property": {
                          "detectedLanguages": [
                            {
                              "languageCode": "en"
                            }
                          ]
                        },
                        "boundingBox": {
                          "vertices": [
                            {
                              "x": 397,
                              "y": 248
                            },
                            {
                              "x": 411,
                              "y": 248
                            },
                            {
                              "x": 411,
                              "y": 256
                            },
                            {
                              "x": 397,
                              "y": 256
                            }
                          ]
                        },
                        "symbols": [
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 397,
                                  "y": 248
                                },
                                {
                                  "x": 406,
                                  "y": 248
                                },
                                {
                                  "x": 406,
                                  "y": 256
                                },
                                {
                                  "x": 397,
                                  "y": 256
                                }
                              ]
                            },
                            "text": "O"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ],
                              "detectedBreak": {
                                "type": "EOL_SURE_SPACE"
                              }
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 407,
                                  "y": 248
                                },
                                {
                                  "x": 411,
                                  "y": 248
                                },
                                {
                                  "x": 411,
                                  "y": 256
                                },
                                {
                                  "x": 407,
                                  "y": 256
                                }
                              ]
                            },
                            "text": "n"
                          }
                        ]
                      },
                      {
                        "property": {
                          "detectedLanguages": [
                            {
                              "languageCode": "en"
                            }
                          ]
                        },
                        "boundingBox": {
                          "vertices": [
                            {
                              "x": 355,
                              "y": 258
                            },
                            {
                              "x": 368,
                              "y": 258
                            },
                            {
                              "x": 368,
                              "y": 271
                            },
                            {
                              "x": 355,
                              "y": 271
                            }
                          ]
                        },
                        "symbols": [
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 355,
                                  "y": 260
                                },
                                {
                                  "x": 358,
                                  "y": 260
                                },
                                {
                                  "x": 358,
                                  "y": 271
                                },
                                {
                                  "x": 355,
                                  "y": 271
                                }
                              ]
                            },
                            "text": "1"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ],
                              "detectedBreak": {
                                "type": "SPACE"
                              }
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 363,
                                  "y": 258
                                },
                                {
                                  "x": 368,
                                  "y": 258
                                },
                                {
                                  "x": 368,
                                  "y": 271
                                },
                                {
                                  "x": 363,
                                  "y": 271
                                }
                              ]
                            },
                            "text": "5"
                          }
                        ]
                      },
                      {
                        "property": {
                          "detectedLanguages": [
                            {
                              "languageCode": "en"
                            }
                          ]
                        },
                        "boundingBox": {
                          "vertices": [
                            {
                              "x": 376,
                              "y": 260
                            },
                            {
                              "x": 406,
                              "y": 260
                            },
                            {
                              "x": 406,
                              "y": 271
                            },
                            {
                              "x": 376,
                              "y": 271
                            }
                          ]
                        },
                        "symbols": [
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 376,
                                  "y": 260
                                },
                                {
                                  "x": 385,
                                  "y": 260
                                },
                                {
                                  "x": 385,
                                  "y": 271
                                },
                                {
                                  "x": 376,
                                  "y": 271
                                }
                              ]
                            },
                            "text": "M"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 388,
                                  "y": 260
                                },
                                {
                                  "x": 397,
                                  "y": 260
                                },
                                {
                                  "x": 397,
                                  "y": 271
                                },
                                {
                                  "x": 388,
                                  "y": 271
                                }
                              ]
                            },
                            "text": "A"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ],
                              "detectedBreak": {
                                "type": "SPACE"
                              }
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 399,
                                  "y": 260
                                },
                                {
                                  "x": 406,
                                  "y": 260
                                },
                                {
                                  "x": 406,
                                  "y": 271
                                },
                                {
                                  "x": 399,
                                  "y": 271
                                }
                              ]
                            },
                            "text": "Y"
                          }
                        ]
                      },
                      {
                        "property": {
                          "detectedLanguages": [
                            {
                              "languageCode": "en"
                            }
                          ]
                        },
                        "boundingBox": {
                          "vertices": [
                            {
                              "x": 413,
                              "y": 260
                            },
                            {
                              "x": 427,
                              "y": 260
                            },
                            {
                              "x": 427,
                              "y": 271
                            },
                            {
                              "x": 413,
                              "y": 271
                            }
                          ]
                        },
                        "symbols": [
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 413,
                                  "y": 260
                                },
                                {
                                  "x": 416,
                                  "y": 260
                                },
                                {
                                  "x": 416,
                                  "y": 271
                                },
                                {
                                  "x": 413,
                                  "y": 271
                                }
                              ]
                            },
                            "text": "1"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ],
                              "detectedBreak": {
                                "type": "EOL_SURE_SPACE"
                              }
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 420,
                                  "y": 260
                                },
                                {
                                  "x": 427,
                                  "y": 260
                                },
                                {
                                  "x": 427,
                                  "y": 271
                                },
                                {
                                  "x": 420,
                                  "y": 271
                                }
                              ]
                            },
                            "text": "8"
                          }
                        ]
                      }
                    ]
                  }
                ],
                "blockType": "TEXT"
              },
              {
                "property": {
                  "detectedLanguages": [
                    {
                      "languageCode": "en",
                      "confidence": 1
                    }
                  ]
                },
                "boundingBox": {
                  "vertices": [
                    {
                      "x": 222,
                      "y": 248
                    },
                    {
                      "x": 296,
                      "y": 247
                    },
                    {
                      "x": 296,
                      "y": 273
                    },
                    {
                      "x": 222,
                      "y": 274
                    }
                  ]
                },
                "paragraphs": [
                  {
                    "property": {
                      "detectedLanguages": [
                        {
                          "languageCode": "en",
                          "confidence": 1
                        }
                      ]
                    },
                    "boundingBox": {
                      "vertices": [
                        {
                          "x": 222,
                          "y": 248
                        },
                        {
                          "x": 296,
                          "y": 247
                        },
                        {
                          "x": 296,
                          "y": 273
                        },
                        {
                          "x": 222,
                          "y": 274
                        }
                      ]
                    },
                    "words": [
                      {
                        "property": {
                          "detectedLanguages": [
                            {
                              "languageCode": "en"
                            }
                          ]
                        },
                        "boundingBox": {
                          "vertices": [
                            {
                              "x": 222,
                              "y": 248
                            },
                            {
                              "x": 256,
                              "y": 247
                            },
                            {
                              "x": 256,
                              "y": 257
                            },
                            {
                              "x": 222,
                              "y": 258
                            }
                          ]
                        },
                        "symbols": [
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 222,
                                  "y": 248
                                },
                                {
                                  "x": 232,
                                  "y": 248
                                },
                                {
                                  "x": 232,
                                  "y": 258
                                },
                                {
                                  "x": 222,
                                  "y": 258
                                }
                              ]
                            },
                            "text": "s"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 233,
                                  "y": 248
                                },
                                {
                                  "x": 240,
                                  "y": 248
                                },
                                {
                                  "x": 240,
                                  "y": 258
                                },
                                {
                                  "x": 233,
                                  "y": 258
                                }
                              ]
                            },
                            "text": "s"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 241,
                                  "y": 248
                                },
                                {
                                  "x": 245,
                                  "y": 248
                                },
                                {
                                  "x": 245,
                                  "y": 258
                                },
                                {
                                  "x": 241,
                                  "y": 258
                                }
                              ]
                            },
                            "text": "u"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 246,
                                  "y": 248
                                },
                                {
                                  "x": 249,
                                  "y": 248
                                },
                                {
                                  "x": 249,
                                  "y": 258
                                },
                                {
                                  "x": 246,
                                  "y": 258
                                }
                              ]
                            },
                            "text": "e"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ],
                              "detectedBreak": {
                                "type": "SPACE"
                              }
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 250,
                                  "y": 248
                                },
                                {
                                  "x": 256,
                                  "y": 248
                                },
                                {
                                  "x": 256,
                                  "y": 258
                                },
                                {
                                  "x": 250,
                                  "y": 258
                                }
                              ]
                            },
                            "text": "d"
                          }
                        ]
                      },
                      {
                        "property": {
                          "detectedLanguages": [
                            {
                              "languageCode": "en"
                            }
                          ]
                        },
                        "boundingBox": {
                          "vertices": [
                            {
                              "x": 261,
                              "y": 248
                            },
                            {
                              "x": 275,
                              "y": 248
                            },
                            {
                              "x": 275,
                              "y": 256
                            },
                            {
                              "x": 261,
                              "y": 256
                            }
                          ]
                        },
                        "symbols": [
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 261,
                                  "y": 248
                                },
                                {
                                  "x": 268,
                                  "y": 248
                                },
                                {
                                  "x": 268,
                                  "y": 256
                                },
                                {
                                  "x": 261,
                                  "y": 256
                                }
                              ]
                            },
                            "text": "O"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ],
                              "detectedBreak": {
                                "type": "EOL_SURE_SPACE"
                              }
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 270,
                                  "y": 251
                                },
                                {
                                  "x": 275,
                                  "y": 251
                                },
                                {
                                  "x": 275,
                                  "y": 256
                                },
                                {
                                  "x": 270,
                                  "y": 256
                                }
                              ]
                            },
                            "text": "n"
                          }
                        ]
                      },
                      {
                        "property": {
                          "detectedLanguages": [
                            {
                              "languageCode": "en"
                            }
                          ]
                        },
                        "boundingBox": {
                          "vertices": [
                            {
                              "x": 226,
                              "y": 259
                            },
                            {
                              "x": 238,
                              "y": 259
                            },
                            {
                              "x": 238,
                              "y": 274
                            },
                            {
                              "x": 226,
                              "y": 274
                            }
                          ]
                        },
                        "symbols": [
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ],
                              "detectedBreak": {
                                "type": "SPACE"
                              }
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 226,
                                  "y": 259
                                },
                                {
                                  "x": 238,
                                  "y": 259
                                },
                                {
                                  "x": 238,
                                  "y": 274
                                },
                                {
                                  "x": 226,
                                  "y": 274
                                }
                              ]
                            },
                            "text": "6"
                          }
                        ]
                      },
                      {
                        "property": {
                          "detectedLanguages": [
                            {
                              "languageCode": "en"
                            }
                          ]
                        },
                        "boundingBox": {
                          "vertices": [
                            {
                              "x": 245,
                              "y": 260
                            },
                            {
                              "x": 275,
                              "y": 260
                            },
                            {
                              "x": 275,
                              "y": 272
                            },
                            {
                              "x": 245,
                              "y": 272
                            }
                          ]
                        },
                        "symbols": [
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 245,
                                  "y": 260
                                },
                                {
                                  "x": 255,
                                  "y": 260
                                },
                                {
                                  "x": 255,
                                  "y": 272
                                },
                                {
                                  "x": 245,
                                  "y": 272
                                }
                              ]
                            },
                            "text": "M"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 257,
                                  "y": 260
                                },
                                {
                                  "x": 266,
                                  "y": 260
                                },
                                {
                                  "x": 266,
                                  "y": 271
                                },
                                {
                                  "x": 257,
                                  "y": 271
                                }
                              ]
                            },
                            "text": "A"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ],
                              "detectedBreak": {
                                "type": "SPACE"
                              }
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 268,
                                  "y": 260
                                },
                                {
                                  "x": 275,
                                  "y": 260
                                },
                                {
                                  "x": 275,
                                  "y": 271
                                },
                                {
                                  "x": 268,
                                  "y": 271
                                }
                              ]
                            },
                            "text": "Y"
                          }
                        ]
                      },
                      {
                        "property": {
                          "detectedLanguages": [
                            {
                              "languageCode": "en"
                            }
                          ]
                        },
                        "boundingBox": {
                          "vertices": [
                            {
                              "x": 281,
                              "y": 260
                            },
                            {
                              "x": 296,
                              "y": 260
                            },
                            {
                              "x": 296,
                              "y": 271
                            },
                            {
                              "x": 281,
                              "y": 271
                            }
                          ]
                        },
                        "symbols": [
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 281,
                                  "y": 260
                                },
                                {
                                  "x": 287,
                                  "y": 260
                                },
                                {
                                  "x": 287,
                                  "y": 271
                                },
                                {
                                  "x": 281,
                                  "y": 271
                                }
                              ]
                            },
                            "text": "0"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ],
                              "detectedBreak": {
                                "type": "EOL_SURE_SPACE"
                              }
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 289,
                                  "y": 260
                                },
                                {
                                  "x": 296,
                                  "y": 260
                                },
                                {
                                  "x": 296,
                                  "y": 271
                                },
                                {
                                  "x": 289,
                                  "y": 271
                                }
                              ]
                            },
                            "text": "8"
                          }
                        ]
                      }
                    ]
                  }
                ],
                "blockType": "TEXT"
              },
              {
                "property": {
                  "detectedLanguages": [
                    {
                      "languageCode": "en",
                      "confidence": 0.81
                    }
                  ]
                },
                "boundingBox": {
                  "vertices": [
                    {
                      "x": 26,
                      "y": 271
                    },
                    {
                      "x": 421,
                      "y": 270
                    },
                    {
                      "x": 421,
                      "y": 296
                    },
                    {
                      "x": 26,
                      "y": 297
                    }
                  ]
                },
                "paragraphs": [
                  {
                    "property": {
                      "detectedLanguages": [
                        {
                          "languageCode": "en",
                          "confidence": 0.81
                        }
                      ]
                    },
                    "boundingBox": {
                      "vertices": [
                        {
                          "x": 26,
                          "y": 271
                        },
                        {
                          "x": 421,
                          "y": 270
                        },
                        {
                          "x": 421,
                          "y": 296
                        },
                        {
                          "x": 26,
                          "y": 297
                        }
                      ]
                    },
                    "words": [
                      {
                        "boundingBox": {
                          "vertices": [
                            {
                              "x": 26,
                              "y": 271
                            },
                            {
                              "x": 89,
                              "y": 271
                            },
                            {
                              "x": 89,
                              "y": 285
                            },
                            {
                              "x": 26,
                              "y": 285
                            }
                          ]
                        },
                        "symbols": [
                          {
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 26,
                                  "y": 271
                                },
                                {
                                  "x": 40,
                                  "y": 271
                                },
                                {
                                  "x": 40,
                                  "y": 285
                                },
                                {
                                  "x": 26,
                                  "y": 285
                                }
                              ]
                            },
                            "text": "A"
                          },
                          {
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 41,
                                  "y": 271
                                },
                                {
                                  "x": 47,
                                  "y": 271
                                },
                                {
                                  "x": 47,
                                  "y": 285
                                },
                                {
                                  "x": 41,
                                  "y": 285
                                }
                              ]
                            },
                            "text": "1"
                          },
                          {
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 48,
                                  "y": 271
                                },
                                {
                                  "x": 55,
                                  "y": 271
                                },
                                {
                                  "x": 55,
                                  "y": 285
                                },
                                {
                                  "x": 48,
                                  "y": 285
                                }
                              ]
                            },
                            "text": "2"
                          },
                          {
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 56,
                                  "y": 271
                                },
                                {
                                  "x": 65,
                                  "y": 271
                                },
                                {
                                  "x": 65,
                                  "y": 285
                                },
                                {
                                  "x": 56,
                                  "y": 285
                                }
                              ]
                            },
                            "text": "3"
                          },
                          {
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 66,
                                  "y": 271
                                },
                                {
                                  "x": 70,
                                  "y": 271
                                },
                                {
                                  "x": 70,
                                  "y": 285
                                },
                                {
                                  "x": 66,
                                  "y": 285
                                }
                              ]
                            },
                            "text": "4"
                          },
                          {
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 71,
                                  "y": 271
                                },
                                {
                                  "x": 80,
                                  "y": 271
                                },
                                {
                                  "x": 80,
                                  "y": 285
                                },
                                {
                                  "x": 71,
                                  "y": 285
                                }
                              ]
                            },
                            "text": "5"
                          },
                          {
                            "property": {
                              "detectedBreak": {
                                "type": "EOL_SURE_SPACE"
                              }
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 81,
                                  "y": 271
                                },
                                {
                                  "x": 89,
                                  "y": 271
                                },
                                {
                                  "x": 89,
                                  "y": 285
                                },
                                {
                                  "x": 81,
                                  "y": 285
                                }
                              ]
                            },
                            "text": "6"
                          }
                        ]
                      },
                      {
                        "property": {
                          "detectedLanguages": [
                            {
                              "languageCode": "en"
                            }
                          ]
                        },
                        "boundingBox": {
                          "vertices": [
                            {
                              "x": 45,
                              "y": 283
                            },
                            {
                              "x": 57,
                              "y": 283
                            },
                            {
                              "x": 57,
                              "y": 296
                            },
                            {
                              "x": 45,
                              "y": 296
                            }
                          ]
                        },
                        "symbols": [
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ],
                              "detectedBreak": {
                                "type": "SPACE"
                              }
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 45,
                                  "y": 283
                                },
                                {
                                  "x": 57,
                                  "y": 283
                                },
                                {
                                  "x": 57,
                                  "y": 296
                                },
                                {
                                  "x": 45,
                                  "y": 296
                                }
                              ]
                            },
                            "text": "m"
                          }
                        ]
                      },
                      {
                        "property": {
                          "detectedLanguages": [
                            {
                              "languageCode": "en"
                            }
                          ]
                        },
                        "boundingBox": {
                          "vertices": [
                            {
                              "x": 75,
                              "y": 283
                            },
                            {
                              "x": 139,
                              "y": 283
                            },
                            {
                              "x": 139,
                              "y": 295
                            },
                            {
                              "x": 75,
                              "y": 295
                            }
                          ]
                        },
                        "symbols": [
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 75,
                                  "y": 283
                                },
                                {
                                  "x": 92,
                                  "y": 283
                                },
                                {
                                  "x": 92,
                                  "y": 295
                                },
                                {
                                  "x": 75,
                                  "y": 295
                                }
                              ]
                            },
                            "text": "U"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 93,
                                  "y": 283
                                },
                                {
                                  "x": 97,
                                  "y": 283
                                },
                                {
                                  "x": 97,
                                  "y": 295
                                },
                                {
                                  "x": 93,
                                  "y": 295
                                }
                              ]
                            },
                            "text": "N"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 98,
                                  "y": 283
                                },
                                {
                                  "x": 111,
                                  "y": 283
                                },
                                {
                                  "x": 111,
                                  "y": 295
                                },
                                {
                                  "x": 98,
                                  "y": 295
                                }
                              ]
                            },
                            "text": "I"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 112,
                                  "y": 283
                                },
                                {
                                  "x": 118,
                                  "y": 283
                                },
                                {
                                  "x": 118,
                                  "y": 295
                                },
                                {
                                  "x": 112,
                                  "y": 295
                                }
                              ]
                            },
                            "text": "T"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 119,
                                  "y": 283
                                },
                                {
                                  "x": 129,
                                  "y": 283
                                },
                                {
                                  "x": 129,
                                  "y": 295
                                },
                                {
                                  "x": 119,
                                  "y": 295
                                }
                              ]
                            },
                            "text": "E"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ],
                              "detectedBreak": {
                                "type": "SPACE"
                              }
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 130,
                                  "y": 283
                                },
                                {
                                  "x": 139,
                                  "y": 283
                                },
                                {
                                  "x": 139,
                                  "y": 295
                                },
                                {
                                  "x": 130,
                                  "y": 295
                                }
                              ]
                            },
                            "text": "D"
                          }
                        ]
                      },
                      {
                        "property": {
                          "detectedLanguages": [
                            {
                              "languageCode": "en"
                            }
                          ]
                        },
                        "boundingBox": {
                          "vertices": [
                            {
                              "x": 148,
                              "y": 287
                            },
                            {
                              "x": 210,
                              "y": 287
                            },
                            {
                              "x": 210,
                              "y": 294
                            },
                            {
                              "x": 148,
                              "y": 294
                            }
                          ]
                        },
                        "symbols": [
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 148,
                                  "y": 287
                                },
                                {
                                  "x": 160,
                                  "y": 287
                                },
                                {
                                  "x": 160,
                                  "y": 294
                                },
                                {
                                  "x": 148,
                                  "y": 294
                                }
                              ]
                            },
                            "text": "S"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 161,
                                  "y": 287
                                },
                                {
                                  "x": 167,
                                  "y": 287
                                },
                                {
                                  "x": 167,
                                  "y": 294
                                },
                                {
                                  "x": 161,
                                  "y": 294
                                }
                              ]
                            },
                            "text": "T"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 168,
                                  "y": 287
                                },
                                {
                                  "x": 176,
                                  "y": 287
                                },
                                {
                                  "x": 176,
                                  "y": 294
                                },
                                {
                                  "x": 168,
                                  "y": 294
                                }
                              ]
                            },
                            "text": "A"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 177,
                                  "y": 287
                                },
                                {
                                  "x": 188,
                                  "y": 287
                                },
                                {
                                  "x": 188,
                                  "y": 294
                                },
                                {
                                  "x": 177,
                                  "y": 294
                                }
                              ]
                            },
                            "text": "T"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 189,
                                  "y": 287
                                },
                                {
                                  "x": 204,
                                  "y": 287
                                },
                                {
                                  "x": 204,
                                  "y": 294
                                },
                                {
                                  "x": 189,
                                  "y": 294
                                }
                              ]
                            },
                            "text": "E"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ],
                              "detectedBreak": {
                                "type": "SPACE"
                              }
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 205,
                                  "y": 287
                                },
                                {
                                  "x": 210,
                                  "y": 287
                                },
                                {
                                  "x": 210,
                                  "y": 294
                                },
                                {
                                  "x": 205,
                                  "y": 294
                                }
                              ]
                            },
                            "text": "S"
                          }
                        ]
                      },
                      {
                        "property": {
                          "detectedLanguages": [
                            {
                              "languageCode": "en"
                            }
                          ]
                        },
                        "boundingBox": {
                          "vertices": [
                            {
                              "x": 219,
                              "y": 287
                            },
                            {
                              "x": 333,
                              "y": 287
                            },
                            {
                              "x": 333,
                              "y": 294
                            },
                            {
                              "x": 219,
                              "y": 294
                            }
                          ]
                        },
                        "symbols": [
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 219,
                                  "y": 287
                                },
                                {
                                  "x": 229,
                                  "y": 287
                                },
                                {
                                  "x": 229,
                                  "y": 294
                                },
                                {
                                  "x": 219,
                                  "y": 294
                                }
                              ]
                            },
                            "text": "D"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 232,
                                  "y": 287
                                },
                                {
                                  "x": 240,
                                  "y": 287
                                },
                                {
                                  "x": 240,
                                  "y": 294
                                },
                                {
                                  "x": 232,
                                  "y": 294
                                }
                              ]
                            },
                            "text": "E"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 242,
                                  "y": 287
                                },
                                {
                                  "x": 251,
                                  "y": 287
                                },
                                {
                                  "x": 251,
                                  "y": 294
                                },
                                {
                                  "x": 242,
                                  "y": 294
                                }
                              ]
                            },
                            "text": "P"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 253,
                                  "y": 287
                                },
                                {
                                  "x": 263,
                                  "y": 287
                                },
                                {
                                  "x": 263,
                                  "y": 294
                                },
                                {
                                  "x": 253,
                                  "y": 294
                                }
                              ]
                            },
                            "text": "A"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 265,
                                  "y": 287
                                },
                                {
                                  "x": 274,
                                  "y": 287
                                },
                                {
                                  "x": 274,
                                  "y": 294
                                },
                                {
                                  "x": 265,
                                  "y": 294
                                }
                              ]
                            },
                            "text": "R"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 277,
                                  "y": 287
                                },
                                {
                                  "x": 285,
                                  "y": 287
                                },
                                {
                                  "x": 285,
                                  "y": 294
                                },
                                {
                                  "x": 277,
                                  "y": 294
                                }
                              ]
                            },
                            "text": "T"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 287,
                                  "y": 287
                                },
                                {
                                  "x": 299,
                                  "y": 287
                                },
                                {
                                  "x": 299,
                                  "y": 294
                                },
                                {
                                  "x": 287,
                                  "y": 294
                                }
                              ]
                            },
                            "text": "M"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 302,
                                  "y": 287
                                },
                                {
                                  "x": 310,
                                  "y": 287
                                },
                                {
                                  "x": 310,
                                  "y": 294
                                },
                                {
                                  "x": 302,
                                  "y": 294
                                }
                              ]
                            },
                            "text": "E"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 313,
                                  "y": 287
                                },
                                {
                                  "x": 322,
                                  "y": 287
                                },
                                {
                                  "x": 322,
                                  "y": 294
                                },
                                {
                                  "x": 313,
                                  "y": 294
                                }
                              ]
                            },
                            "text": "N"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ],
                              "detectedBreak": {
                                "type": "SPACE"
                              }
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 325,
                                  "y": 287
                                },
                                {
                                  "x": 333,
                                  "y": 287
                                },
                                {
                                  "x": 333,
                                  "y": 294
                                },
                                {
                                  "x": 325,
                                  "y": 294
                                }
                              ]
                            },
                            "text": "T"
                          }
                        ]
                      },
                      {
                        "property": {
                          "detectedLanguages": [
                            {
                              "languageCode": "en"
                            }
                          ]
                        },
                        "boundingBox": {
                          "vertices": [
                            {
                              "x": 342,
                              "y": 287
                            },
                            {
                              "x": 362,
                              "y": 287
                            },
                            {
                              "x": 362,
                              "y": 294
                            },
                            {
                              "x": 342,
                              "y": 294
                            }
                          ]
                        },
                        "symbols": [
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 342,
                                  "y": 287
                                },
                                {
                                  "x": 352,
                                  "y": 287
                                },
                                {
                                  "x": 352,
                                  "y": 294
                                },
                                {
                                  "x": 342,
                                  "y": 294
                                }
                              ]
                            },
                            "text": "O"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ],
                              "detectedBreak": {
                                "type": "SPACE"
                              }
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 354,
                                  "y": 287
                                },
                                {
                                  "x": 362,
                                  "y": 287
                                },
                                {
                                  "x": 362,
                                  "y": 294
                                },
                                {
                                  "x": 354,
                                  "y": 294
                                }
                              ]
                            },
                            "text": "F"
                          }
                        ]
                      },
                      {
                        "property": {
                          "detectedLanguages": [
                            {
                              "languageCode": "en"
                            }
                          ]
                        },
                        "boundingBox": {
                          "vertices": [
                            {
                              "x": 374,
                              "y": 283
                            },
                            {
                              "x": 421,
                              "y": 283
                            },
                            {
                              "x": 421,
                              "y": 296
                            },
                            {
                              "x": 374,
                              "y": 296
                            }
                          ]
                        },
                        "symbols": [
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 374,
                                  "y": 283
                                },
                                {
                                  "x": 384,
                                  "y": 283
                                },
                                {
                                  "x": 384,
                                  "y": 296
                                },
                                {
                                  "x": 374,
                                  "y": 296
                                }
                              ]
                            },
                            "text": "S"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 385,
                                  "y": 283
                                },
                                {
                                  "x": 391,
                                  "y": 283
                                },
                                {
                                  "x": 391,
                                  "y": 296
                                },
                                {
                                  "x": 385,
                                  "y": 296
                                }
                              ]
                            },
                            "text": "T"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 392,
                                  "y": 283
                                },
                                {
                                  "x": 402,
                                  "y": 283
                                },
                                {
                                  "x": 402,
                                  "y": 296
                                },
                                {
                                  "x": 392,
                                  "y": 296
                                }
                              ]
                            },
                            "text": "A"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 403,
                                  "y": 283
                                },
                                {
                                  "x": 412,
                                  "y": 283
                                },
                                {
                                  "x": 412,
                                  "y": 296
                                },
                                {
                                  "x": 403,
                                  "y": 296
                                }
                              ]
                            },
                            "text": "T"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "en"
                                }
                              ],
                              "detectedBreak": {
                                "type": "EOL_SURE_SPACE"
                              }
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 413,
                                  "y": 283
                                },
                                {
                                  "x": 421,
                                  "y": 283
                                },
                                {
                                  "x": 421,
                                  "y": 296
                                },
                                {
                                  "x": 413,
                                  "y": 296
                                }
                              ]
                            },
                            "text": "E"
                          }
                        ]
                      }
                    ]
                  }
                ],
                "blockType": "TEXT"
              },
              {
                "property": {
                  "detectedLanguages": [
                    {
                      "languageCode": "ceb",
                      "confidence": 1
                    }
                  ]
                },
                "boundingBox": {
                  "vertices": [
                    {
                      "x": 171,
                      "y": 77
                    },
                    {
                      "x": 170,
                      "y": 156
                    },
                    {
                      "x": 159,
                      "y": 156
                    },
                    {
                      "x": 160,
                      "y": 77
                    }
                  ]
                },
                "paragraphs": [
                  {
                    "property": {
                      "detectedLanguages": [
                        {
                          "languageCode": "ceb",
                          "confidence": 1
                        }
                      ]
                    },
                    "boundingBox": {
                      "vertices": [
                        {
                          "x": 171,
                          "y": 77
                        },
                        {
                          "x": 170,
                          "y": 156
                        },
                        {
                          "x": 159,
                          "y": 156
                        },
                        {
                          "x": 160,
                          "y": 77
                        }
                      ]
                    },
                    "words": [
                      {
                        "property": {
                          "detectedLanguages": [
                            {
                              "languageCode": "ceb"
                            }
                          ]
                        },
                        "boundingBox": {
                          "vertices": [
                            {
                              "x": 171,
                              "y": 77
                            },
                            {
                              "x": 170,
                              "y": 156
                            },
                            {
                              "x": 159,
                              "y": 156
                            },
                            {
                              "x": 160,
                              "y": 77
                            }
                          ]
                        },
                        "symbols": [
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "ceb"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 170,
                                  "y": 77
                                },
                                {
                                  "x": 170,
                                  "y": 86
                                },
                                {
                                  "x": 161,
                                  "y": 86
                                },
                                {
                                  "x": 161,
                                  "y": 77
                                }
                              ]
                            },
                            "text": "U"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "ceb"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 170,
                                  "y": 91
                                },
                                {
                                  "x": 170,
                                  "y": 100
                                },
                                {
                                  "x": 161,
                                  "y": 100
                                },
                                {
                                  "x": 161,
                                  "y": 91
                                }
                              ]
                            },
                            "text": "S"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "ceb"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 171,
                                  "y": 105
                                },
                                {
                                  "x": 171,
                                  "y": 114
                                },
                                {
                                  "x": 161,
                                  "y": 114
                                },
                                {
                                  "x": 161,
                                  "y": 105
                                }
                              ]
                            },
                            "text": "A"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "ceb"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 171,
                                  "y": 120
                                },
                                {
                                  "x": 171,
                                  "y": 127
                                },
                                {
                                  "x": 161,
                                  "y": 127
                                },
                                {
                                  "x": 161,
                                  "y": 120
                                }
                              ]
                            },
                            "text": "U"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "ceb"
                                }
                              ]
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 170,
                                  "y": 133
                                },
                                {
                                  "x": 170,
                                  "y": 142
                                },
                                {
                                  "x": 160,
                                  "y": 142
                                },
                                {
                                  "x": 160,
                                  "y": 133
                                }
                              ]
                            },
                            "text": "S"
                          },
                          {
                            "property": {
                              "detectedLanguages": [
                                {
                                  "languageCode": "ceb"
                                }
                              ],
                              "detectedBreak": {
                                "type": "EOL_SURE_SPACE"
                              }
                            },
                            "boundingBox": {
                              "vertices": [
                                {
                                  "x": 170,
                                  "y": 148
                                },
                                {
                                  "x": 170,
                                  "y": 156
                                },
                                {
                                  "x": 159,
                                  "y": 156
                                },
                                {
                                  "x": 159,
                                  "y": 148
                                }
                              ]
                            },
                            "text": "A"
                          }
                        ]
                      }
                    ]
                  }
                ],
                "blockType": "TEXT"
              }
            ]
          }
        ],
        "text": "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
      }
    }
  ]
}


"""
